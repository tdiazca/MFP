---
name: generador-cuadernos-practicos
description: transformar un manual de estudio consolidado y uno o varios materiales de tutoría del mismo tema en un cuaderno práctico complementario, visual y compacto de 6 a 8 páginas. usar cuando se solicite crear un pdf o word de repaso aplicado con aclaraciones, dudas, ejemplos, casos, ejercicios, procedimientos, comparaciones o preparación práctica del examen, sin duplicar el manual ni consultar fuentes externas.
---

# Generador de cuadernos prácticos

## Objetivo

Crear un cuaderno práctico que convierta una o varias tutorías en un recurso breve de aplicación y repaso. Complementar el manual de estudio sin convertir el resultado en un segundo manual ni en un resumen cronológico de la tutoría.

## 1. Recoger los datos

Identificar:

- asignatura;
- tema o unidad;
- archivo del manual consolidado;
- archivo o archivos de tutoría;
- nombre y formato de salida.

Si falta el manual, falta la tutoría o los archivos no parecen corresponder al mismo tema, informar y pedir confirmación antes de continuar.

Usar PDF como formato predeterminado y Word solo cuando el usuario lo solicite.

## 2. Aplicar la jerarquía de fuentes

Usar exclusivamente:

1. **Tutoría o tutorías**: fuente principal del contenido práctico, las aclaraciones, ejemplos, dudas, ejercicios, procedimientos e indicaciones del docente.
2. **Manual de estudio**: fuente teórica consolidada para recordar lo imprescindible, mantener la terminología y relacionar la práctica con el tema.

No consultar internet ni otras fuentes. No reabrir los materiales originales empleados para generar el manual salvo petición expresa.

Si la tutoría contiene una corrección o aclaración posterior que difiere del manual, priorizar la tutoría y señalar la diferencia únicamente cuando afecte al estudio.

Si las fuentes no permiten explicar algo, indicarlo. No completar lagunas con conocimientos externos.

## 3. Analizar la tutoría antes de redactar

Clasificar su contenido según proceda:

- aclaraciones conceptuales;
- preguntas y respuestas;
- ejemplos;
- casos prácticos;
- ejercicios o problemas;
- análisis de textos, documentos, normativa o situaciones;
- procedimientos o demostraciones;
- preparación de actividades o examen;
- combinación de varios tipos.

Consultar `references/tipos-de-tutoria.md` para decidir cómo transformar cada tipo de contenido.

Seleccionar solo contenido con valor académico. Omitir saludos, incidencias técnicas, organización de la sesión, repeticiones, digresiones y comentarios administrativos.

## 4. Diseñar una estructura adaptable

No imponer una estructura fija. Construir únicamente las secciones necesarias:

1. **Aportaciones de la tutoría**: breve explicación de qué añade o aclara respecto al manual.
2. **Contenido práctico principal**: organizado por temas o problemas, no por orden cronológico.
3. **Comparación o decisión**: solo cuando haya elementos que deban distinguirse o elegirse.
4. **Repaso práctico final**: una única página con lo esencial para aplicar y evitar errores.

Para casos o ejercicios, usar una secuencia compacta:

**Enunciado → preguntas → resuelve tú → solución → claves para recordar**

Presentar una sola solución suficientemente razonada. No añadir otra explicación que repita la tabla o los pasos.

Consultar `references/plantillas-cuaderno.md` para elegir el patrón adecuado.

## 5. Controlar la redundancia

- No repetir en texto lo que una tabla ya explica suficientemente.
- No crear varios mapas, tablas o checklists equivalentes.
- No duplicar el manual.
- Incluir únicamente la teoría imprescindible para comprender la aplicación.
- Utilizar referencias internas cuando un concepto ya se haya explicado.
- Reservar la síntesis global para el repaso final.

## 6. Gestionar ejercicios adicionales

No generar ejercicios, casos ni preguntas nuevas por defecto.

Si la tutoría ya contiene práctica suficiente, conservar solo la práctica del docente.

Generar ejercicios adicionales únicamente cuando el usuario lo pida expresamente o autorice una propuesta porque la tutoría carece de práctica suficiente.

Identificarlos como **Ejercicio generado por Claude** y construirlos solo con conceptos presentes en las fuentes.

## 7. Extensión y diseño

Objetivo: **6 a 8 páginas**.

Superar 8 páginas únicamente cuando eliminar contenido suponga perder aclaraciones, ejercicios o casos relevantes. Si el material es escaso, no rellenar artificialmente hasta 6 páginas.

Priorizar:

- tablas para comparar;
- esquemas para procesos y relaciones;
- listas para pasos y comprobaciones;
- diagramas de decisión cuando haya alternativas;
- recuadros para aclaraciones y errores;
- texto breve para explicar razonamientos.

Evitar decoración sin función didáctica, párrafos largos, espacios vacíos excesivos y tablas demasiado densas.

Cuando facilite la trazabilidad, se pueden usar con moderación:

- `[T]` información de la tutoría;
- `[M]` información del manual;
- `[C]` síntesis de Claude basada en ambas fuentes.

## 8. Verificación final

Antes de generar el archivo, comprobar que:

- manual y tutoría corresponden al mismo tema;
- el cuaderno complementa y no duplica el manual;
- el contenido práctico procede de la tutoría;
- la teoría procede del manual;
- no se ha consultado información externa;
- no faltan aclaraciones o actividades relevantes;
- la estructura refleja el tipo real de tutoría;
- no hay secciones funcionalmente repetidas;
- cada caso o ejercicio tiene una única solución clara;
- no se generaron ejercicios nuevos sin autorización;
- el repaso final sintetiza sin volver a desarrollar todo;
- el resultado se mantiene, siempre que sea posible, entre 6 y 8 páginas;
- el nombre y formato de salida coinciden con la petición.

Generar directamente el archivo solicitado.
