# Tratamiento según el tipo de tutoría

## Índice

1. Aclaraciones conceptuales
2. Preguntas y respuestas
3. Ejemplos
4. Casos prácticos
5. Ejercicios o problemas
6. Análisis de documentos o normativa
7. Procedimientos o demostraciones
8. Preparación de evaluación

## 1. Aclaraciones conceptuales

Presentar cada aclaración mediante: concepto o duda, explicación breve, relación con el manual y error que evita. Incluir solo matices nuevos o correctivos.

## 2. Preguntas y respuestas

Agrupar por tema, no por orden cronológico. Reformular la pregunta para hacerla autónoma y conservar la respuesta fiel al docente. Fusionar preguntas equivalentes.

## 3. Ejemplos

Indicar situación, concepto ilustrado, explicación y aprendizaje clave. Omitir ejemplos redundantes o anecdóticos.

## 4. Casos prácticos

Usar: enunciado, preguntas, espacio breve de resolución, solución compacta y hasta tres claves para recordar. Mantener datos y conclusiones del profesor.

## 5. Ejercicios o problemas

Usar: enunciado, datos, procedimiento, solución paso a paso y error frecuente. No añadir métodos no presentes en las fuentes.

## 6. Análisis de documentos o normativa

Identificar objeto, elementos examinados, criterios usados, interpretación del docente y errores habituales. No actualizar normativa mediante internet.

## 7. Procedimientos o demostraciones

Convertir en pasos numerados, checklist o diagrama. Incluir decisiones, requisitos y puntos de control. Eliminar repeticiones orales.

## 8. Preparación de evaluación

Separar contenido confirmado por el docente, contenido enfatizado y recomendaciones de estudio. No convertir una pista en certeza de examen.
