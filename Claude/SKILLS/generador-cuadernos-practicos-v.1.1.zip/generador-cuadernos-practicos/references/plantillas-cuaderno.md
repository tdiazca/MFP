# Plantillas adaptables del cuaderno

## Índice

1. Apertura
2. Aclaración o duda
3. Ejemplo
4. Caso práctico
5. Ejercicio o problema
6. Procedimiento
7. Comparación
8. Repaso final

## 1. Apertura

- Tema y asignatura.
- Archivos utilizados.
- Qué aporta la tutoría al manual, en un máximo de cinco líneas.

## 2. Aclaración o duda

### [Concepto o pregunta]

- **Aclaración:** [explicación]
- **Relación con el manual:** [referencia breve]
- **Evita confundir:** [error]

## 3. Ejemplo

### [Título]

- **Situación:** [caso]
- **Ilustra:** [concepto]
- **Explicación:** [razonamiento]
- **Clave:** [aprendizaje]

## 4. Caso práctico

### Caso

[Enunciado fiel]

### Preguntas

[Preguntas necesarias]

### Resuelve tú

[Espacio o tabla breve]

### Solución

[Una única solución compacta]

### Claves para recordar

Máximo tres ideas.

## 5. Ejercicio o problema

- **Enunciado:** [texto]
- **Datos:** [datos]
- **Procedimiento:** [pasos]
- **Resultado:** [solución]
- **Error frecuente:** [advertencia]

## 6. Procedimiento

1. [Paso]
2. [Paso]
3. [Paso]

Añadir decisiones o checklist solo si mejoran la aplicación.

## 7. Comparación

| Elemento | Cuándo se usa | Qué comprobar | Confusión frecuente |
|---|---|---|---|
| [elemento] | [uso] | [control] | [error] |

Usar una sola tabla o diagrama para cada comparación. No duplicarla al final.

## 8. Repaso práctico final

Crear una única página con:

- aclaraciones esenciales;
- procedimientos o decisiones;
- diferencias clave;
- errores frecuentes;
- indicaciones prácticas del docente;
- contenido práctico relevante para la evaluación.

No volver a desarrollar los casos completos.
