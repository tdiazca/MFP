# Reglas complementarias APA 7

Usar este archivo como apoyo de `SKILL.md`.

Si el proyecto contiene `G01_Guia_Normas_APA_7_1.pdf`, utilizar esa guía como referencia principal para elaborar y revisar las citas y referencias en formato APA 7.

Utilizar las reglas de este archivo como complemento cuando:

- la guía del proyecto no esté disponible;
- la guía no cubra un tipo de fuente o caso concreto;
- sea necesario verificar coherencia entre citas y referencias;
- sea necesario aplicar una regla operativa no desarrollada en la guía.

Si `G01_Guia_Normas_APA_7_1.pdf` no está disponible, aplicar este archivo e indicar expresamente que el formato no pudo contrastarse con la guía del proyecto.

## 1. Jerarquía de aplicación

Aplicar las instrucciones en este orden:

1. Instrucciones expresas del enunciado, la plantilla, la rúbrica o la universidad.
2. `G01_Guia_Normas_APA_7_1.pdf`, cuando esté disponible en el proyecto.
3. Reglas complementarias incluidas en este archivo.
4. Normas generales de APA 7 que puedan verificarse mediante fuentes fiables.

Si existe una contradicción material entre el enunciado, la rúbrica y la guía del proyecto:

- identificar la contradicción;
- explicar brevemente las distintas opciones;
- solicitar confirmación antes de aplicar una alternativa que pueda afectar a la evaluación.

No incorporar `G01_Guia_Normas_APA_7_1.pdf` a la lista de Referencias por el mero hecho de utilizarla para dar formato.

Referenciar la guía únicamente cuando:

- se cite su contenido;
- se explique una regla incluida en la guía;
- el usuario solicite justificar una decisión de formato con esa guía;
- la actividad exija identificar los documentos normativos utilizados.

## 2. Principios de verificación bibliográfica

No inventar ni completar por aproximación ningún dato bibliográfico.

Comprobar, cuando corresponda:

- autoría;
- orden de autores;
- año o fecha de publicación;
- título exacto;
- nombre de la revista;
- nombre de la editorial;
- institución responsable;
- volumen;
- número;
- páginas;
- número o identificador del artículo;
- edición;
- DOI;
- URL;
- tipo de documento.

Preferir para la verificación:

- el documento original;
- la página oficial de la revista;
- la página de la editorial;
- Crossref u otro registro DOI fiable;
- un repositorio institucional;
- un catálogo bibliográfico fiable;
- la página del organismo responsable;
- un diario oficial.

Mantener la grafía y el orden de autoría del original.

No traducir los nombres de los autores, los títulos de las revistas ni otros datos bibliográficos, salvo que la guía principal establezca una regla específica.

Cuando falte un dato:

- comprobar si realmente es obligatorio para ese tipo de fuente;
- intentar verificarlo en una fuente primaria o fiable;
- señalar su ausencia si no puede localizarse;
- no inferirlo a partir de otros datos;
- no sustituirlo por información aproximada.

Comprobar la correspondencia bidireccional entre citas y referencias:

- cada cita incluida en un texto debe tener su referencia;
- cada referencia de la lista final debe haber sido citada en el texto;
- no deben aparecer referencias que no se hayan utilizado;
- una misma fuente debe conservar la misma autoría y fecha en las citas y en la referencia.

## 3. DOI y URL

Presentar el DOI como enlace:

    https://doi.org/xxxxx

No utilizar formatos como:

    DOI: xxxxx

    doi:xxxxx

    Recuperado de https://doi.org/xxxxx

Si una obra tiene DOI:

- incluir el DOI cuando corresponda según APA 7;
- utilizar el DOI en lugar de la URL ordinaria;
- comprobar que el DOI conduce a la obra citada;
- no añadir además la URL de la revista o editorial, salvo que la guía principal indique otra cosa.

Si una obra no tiene DOI:

- incluir la URL cuando corresponda al tipo de fuente y a la versión consultada;
- utilizar una URL estable y accesible para el lector;
- enlazar directamente al documento o a su página oficial cuando sea posible;
- evitar enlaces temporales o dependientes de una sesión.

No incluir como parte de una referencia:

- enlaces de resultados de Google Scholar;
- enlaces de búsqueda;
- enlaces de bibliotecas que requieran sesión;
- URLs con credenciales;
- enlaces de redirección;
- enlaces de seguimiento;
- enlaces generados temporalmente;
- enlaces a páginas secundarias cuando existe una fuente primaria.

No añadir fecha de recuperación salvo que:

- el contenido esté diseñado para cambiar con el tiempo;
- no exista una versión archivada o estable;
- la guía principal la exija para ese tipo de contenido.

El enlace utilizado para comprobar o acceder a una fuente durante la búsqueda no tiene que formar parte necesariamente de la referencia APA.

Separar siempre:

- el DOI o la URL que forman parte de la referencia APA 7;
- el enlace adicional de acceso o verificación presentado en la ficha de búsqueda.

No añadir el enlace adicional de verificación a la lista final de Referencias cuando APA 7 no lo requiera.

## 4. Citas dentro del texto

### Cita parentética

Estructura general:

    (Apellido, año)

Ejemplo orientativo:

    (García, 2023)

### Cita narrativa

Estructura general:

    Apellido (año)

Ejemplo orientativo:

    García (2023)

### Paráfrasis

Cuando se reformule una idea:

- redactar con una formulación propia;
- incluir la cita correspondiente;
- conservar fielmente el significado de la fuente;
- no sustituir únicamente algunas palabras por sinónimos;
- no presentar como propia una idea procedente de otra fuente;
- no atribuir a la fuente una conclusión más amplia que la realmente respaldada.

La paráfrasis también requiere cita, aunque no reproduzca literalmente las palabras de la fuente.

### Citas textuales

Cuando sea imprescindible reproducir las palabras exactas:

- utilizar comillas en las citas breves;
- aplicar el formato de cita en bloque cuando corresponda;
- añadir la página;
- utilizar otro localizador cuando la fuente no tenga páginas;
- conservar fielmente el texto original;
- identificar cualquier omisión o modificación conforme a APA 7;
- evitar citas textuales innecesariamente largas.

No inventar números de página.

Si no existe paginación, utilizar únicamente un localizador permitido y verificable, como:

- número de párrafo;
- nombre de sección;
- marca temporal en materiales audiovisuales;
- otro localizador admitido por la guía principal.

### Nivel de acceso y alcance de la cita

Si solo se consultó un resumen:

- indicarlo;
- limitar la afirmación a la información contenida en el resumen;
- no atribuir detalles metodológicos no disponibles;
- no presentar la publicación como leída íntegramente.

Si solo se consultó una ficha bibliográfica:

- verificar únicamente la existencia y los datos de la fuente;
- no atribuir resultados;
- no resumir conclusiones;
- no inferir el contenido a partir del título.

## 5. Autoría y situaciones especiales

Aplicar el tratamiento del número de autores según la guía principal.

Comprobar especialmente:

- número total de autores;
- orden de autoría;
- apellidos compuestos;
- partículas del apellido;
- nombres institucionales;
- autoría corporativa;
- autores con el mismo apellido;
- obras del mismo autor y año.

### Autor corporativo

Cuando la fuente haya sido creada por una organización:

- utilizar el nombre oficial de la entidad;
- comprobar si la entidad funciona como autora y editora;
- evitar repetir el nombre de la organización cuando APA 7 indique omitir la editorial por coincidir con la autoría;
- utilizar siglas en las citas únicamente cuando estén justificadas y se hayan presentado correctamente.

### Ausencia de autor

No inventar una autoría.

Aplicar la regla correspondiente al tipo de fuente y utilizar el título en la posición del autor cuando proceda.

### Ausencia de fecha

Utilizar la indicación correspondiente según APA 7 únicamente cuando no sea posible verificar una fecha.

No confundir:

- fecha de publicación;
- fecha de actualización;
- fecha de consulta;
- fecha de depósito en repositorio;
- fecha de la versión publicada.

### Obras del mismo autor y año

Aplicar letras después del año cuando sea necesario distinguir obras del mismo autor publicadas en el mismo año.

Mantener la misma distinción en las citas y las referencias.

No asignar las letras de forma arbitraria sin comprobar el criterio de ordenación aplicable.

### Fuentes secundarias

Priorizar siempre la consulta de la fuente original.

Utilizar una cita secundaria únicamente cuando:

- la fuente original no esté razonablemente disponible;
- resulte necesario citar una idea conocida a través de otra obra;
- se identifique correctamente qué fuente se consultó realmente.

No incluir en la lista final una obra original que no se haya consultado como si se hubiera leído directamente.

### Comunicaciones personales

Aplicar la regla específica de APA 7.

No incluir en la lista de Referencias comunicaciones que no puedan ser recuperadas por el lector, salvo que la guía institucional indique otra cosa.

Proteger la privacidad y no incluir datos personales innecesarios.

## 6. Estructuras orientativas de referencias

Estas estructuras son orientativas.

Verificar siempre la estructura exacta mediante:

1. el enunciado o la rúbrica;
2. `G01_Guia_Normas_APA_7_1.pdf`;
3. las reglas complementarias aplicables.

No forzar una plantilla cuando el tipo de fuente requiera otra estructura.

### Artículo científico con DOI

Estructura orientativa:

    Apellido, N. N., & Apellido, N. N. (Año). Título del artículo. Título de la Revista, volumen(número), páginas o identificador. https://doi.org/xxxxx

Aplicar cursiva al nombre de la revista y al volumen.

Comprobar:

- autoría;
- año;
- título;
- revista;
- volumen;
- número;
- páginas o número de artículo;
- DOI.

### Artículo científico sin DOI

Estructura orientativa:

    Apellido, N. N. (Año). Título del artículo. Título de la Revista, volumen(número), páginas o identificador.

Añadir una URL solo cuando corresponda según APA 7, la versión consultada y la guía principal.

No añadir automáticamente la URL de una base de datos académica.

### Libro

Estructura orientativa:

    Apellido, N. N. (Año). Título del libro. Editorial. https://doi.org/xxxxx

Aplicar cursiva al título del libro.

Incluir el DOI si existe.

No incluir el lugar de publicación, salvo que la guía institucional exija expresamente una adaptación distinta.

### Libro electrónico

Aplicar la estructura correspondiente al libro.

Incluir DOI o URL únicamente cuando corresponda.

No indicar automáticamente el formato del libro electrónico ni el dispositivo de lectura.

### Capítulo de libro editado

Estructura orientativa:

    Apellido, N. N. (Año). Título del capítulo. En N. N. Apellido (Ed.), Título del libro (pp. xx-xx). Editorial. https://doi.org/xxxxx

Aplicar cursiva al título del libro, no al título del capítulo.

Comprobar:

- autoría del capítulo;
- editores del libro;
- título del capítulo;
- título del libro;
- páginas;
- editorial;
- DOI, si existe.

### Informe institucional

Estructura orientativa:

    Entidad o Apellido, N. N. (Año). Título del informe (número de informe, si existe). Entidad editora, si difiere del autor. URL

Comprobar:

- autor individual o corporativo;
- fecha;
- título;
- número del informe;
- organismo editor;
- URL oficial.

Si la entidad autora y la entidad editora coinciden, comprobar si debe omitirse la repetición.

### Tesis doctoral o trabajo académico publicado en repositorio

Estructura orientativa:

    Apellido, N. N. (Año). Título [Tesis doctoral, Nombre de la institución]. Nombre del repositorio. URL

Comprobar:

- tipo exacto de trabajo;
- institución;
- repositorio;
- URL estable;
- estado de publicación.

No presentar un trabajo de máster como tesis doctoral ni una tesis como artículo científico.

### Página web

Estructura orientativa:

    Autor o entidad. (Año, día de mes). Título de la página. Nombre del sitio, si difiere del autor. URL

Comprobar:

- autor o entidad responsable;
- fecha real de publicación o actualización;
- título;
- nombre del sitio;
- URL.

No utilizar la fecha de copyright general del sitio como fecha de publicación de una página concreta si no corresponde.

### Documento o página sin fecha

Aplicar la abreviatura correspondiente según la guía principal.

No utilizar la fecha de consulta como sustituto de la fecha de publicación.

### Informe o documento de organismo internacional

Seguir la estructura de informe institucional.

Verificar:

- edición;
- idioma;
- entidad autora;
- oficina o unidad responsable;
- título;
- número del informe;
- URL oficial.

### Legislación y documentos oficiales

Seguir:

1. la guía institucional;
2. las convenciones exigidas por la universidad;
3. las reglas específicas aplicables al ordenamiento jurídico correspondiente.

No forzar una norma jurídica dentro de una plantilla genérica de artículo, libro o página web.

Comprobar:

- denominación oficial;
- número;
- fecha;
- título;
- boletín o diario oficial;
- fecha de publicación;
- número del boletín;
- páginas o identificador;
- URL oficial;
- versión vigente cuando sea relevante.

Cuando se trabaje con normativa educativa española, utilizar preferentemente:

- Boletín Oficial del Estado;
- diario oficial autonómico correspondiente;
- portal legislativo oficial;
- versión consolidada cuando resulte pertinente.

Distinguir entre:

- norma original;
- corrección de errores;
- modificación;
- derogación;
- texto consolidado.

### Material audiovisual

Aplicar la estructura correspondiente al tipo de recurso.

Comprobar:

- autor o entidad;
- fecha;
- título;
- formato;
- plataforma;
- URL.

En citas textuales o referencias a un momento concreto, utilizar una marca temporal verificable.

### Presentación o material docente

Comprobar si el material es:

- recuperable públicamente;
- interno de la asignatura;
- no publicado;
- alojado en un campus virtual;
- proporcionado directamente por el docente.

Aplicar la regla correspondiente según la guía institucional.

No presentar un material interno no recuperable como una publicación académica pública.

### Inteligencia artificial generativa

Aplicar las reglas institucionales vigentes y las instrucciones de la actividad.

Distinguir entre:

- uso como herramienta;
- contenido citado;
- salida reproducible;
- comunicación no recuperable;
- obligación de declarar el uso.

No incluir automáticamente una herramienta de inteligencia artificial en Referencias si la guía de la universidad establece otro mecanismo de declaración.

## 7. Lista final de Referencias

En el documento académico final, titular la sección **Referencias**.

Incluir únicamente las fuentes citadas en el texto cuando se trate de la bibliografía final de una actividad académica.

No incluir:

- fuentes consultadas pero no utilizadas;
- fuentes descartadas;
- enlaces independientes de verificación;
- comentarios;
- resúmenes;
- anotaciones;
- niveles de acceso;
- motivos de selección;
- resultados de Google Scholar;
- referencias no comprobadas.

### Orden

Ordenar alfabéticamente por:

- apellido del primer autor;
- nombre de la entidad cuando exista autor corporativo;
- título cuando no exista autor y APA 7 indique colocarlo en esa posición.

Aplicar las reglas específicas cuando existan:

- varias obras del mismo autor;
- obras del mismo autor y año;
- autores con los mismos apellidos;
- autoría corporativa;
- ausencia de autor.

### Formato

- Aplicar sangría francesa cuando el formato lo permita.
- Mantener interlineado y espaciado según la plantilla de la actividad.
- No numerar las referencias salvo instrucción expresa.
- Conservar correctamente las cursivas.
- Aplicar la puntuación correspondiente.
- Utilizar mayúsculas y minúsculas según el tipo de elemento.
- Mantener activos los DOI y URL cuando el formato lo permita.
- No añadir un punto después de un DOI o URL si la guía principal indica que debe evitarse.

### Correspondencia con las citas

Antes de entregar:

1. Extraer todas las citas incluidas en el texto.
2. Comprobar que cada cita tiene una referencia.
3. Revisar que cada referencia aparece citada.
4. Comprobar la coincidencia de autores y años.
5. Revisar las letras añadidas a obras del mismo autor y año.
6. Eliminar referencias no utilizadas.
7. Corregir citas sin correspondencia.

## 8. Separación entre referencia y enlace de verificación

Durante la fase de búsqueda, presentar dos campos distintos:

- **Referencia APA 7**
- **Enlace de acceso o verificación**

El enlace de verificación permite al usuario:

- comprobar la existencia de la fuente;
- acceder al texto;
- revisar el registro original;
- verificar un DOI;
- consultar la página oficial.

El enlace de verificación no forma parte automáticamente de la referencia.

Ejemplo de ficha:

    Referencia APA 7: [referencia formateada]
    Enlace de verificación: [enlace estable]
    Nivel de acceso: [texto completo, resumen o ficha bibliográfica]

Cuando se entregue una lista limpia de Referencias:

- eliminar el campo de enlace de verificación;
- conservar únicamente el DOI o la URL que correspondan dentro de la referencia APA 7;
- no añadir anotaciones ni niveles de acceso.

## 9. Prevención de errores y referencias inventadas

No crear una referencia a partir de datos incompletos si no puede verificarse.

No inventar:

- autores;
- iniciales;
- fechas;
- títulos;
- revistas;
- editoriales;
- instituciones;
- volúmenes;
- números;
- páginas;
- identificadores;
- DOI;
- URL.

No asumir que un DOI es correcto por su apariencia.

Abrir o verificar el DOI cuando sea posible.

No atribuir una publicación a una revista basándose únicamente en una cita secundaria.

No convertir una referencia citada dentro de otro documento en una fuente directamente consultada.

Cuando un dato no pueda verificarse:

- indicarlo;
- conservar la fuente como candidata pendiente;
- excluirla de la selección final si el dato es esencial;
- no completar la referencia mediante una estimación.

## 10. Prevención del plagio durante el uso de fuentes

Aunque esta Skill no tenga como objetivo principal redactar trabajos, cualquier síntesis generada debe:

- utilizar una formulación original;
- citar la fuente de las ideas;
- evitar copiar fragmentos extensos;
- utilizar comillas en citas textuales;
- incluir localizador en las citas textuales cuando esté disponible;
- diferenciar hechos, interpretaciones y propuestas;
- no imitar de forma demasiado cercana la estructura y redacción del original;
- no presentar como personal una aportación ajena.

No garantizar un porcentaje concreto de similitud en herramientas de detección de plagio.

Sí puede:

- identificar fragmentos demasiado próximos a la fuente;
- proponer una paráfrasis más profunda;
- comprobar que las ideas ajenas están citadas;
- señalar citas textuales sin comillas;
- detectar referencias ausentes en la lista final.

## 11. Comprobación final de APA 7

Antes de entregar referencias o citas:

- comprobar si `G01_Guia_Normas_APA_7_1.pdf` está disponible;
- aplicar primero las instrucciones de la actividad;
- consultar la guía del proyecto cuando esté disponible;
- verificar los datos bibliográficos;
- comprobar DOI y URL;
- confirmar que los enlaces de verificación están separados;
- revisar las citas narrativas y parentéticas;
- comprobar las citas textuales;
- revisar la correspondencia entre citas y referencias;
- ordenar alfabéticamente la lista;
- revisar cursivas;
- revisar mayúsculas;
- revisar puntuación;
- aplicar sangría francesa cuando el formato lo permita;
- eliminar referencias no citadas;
- no añadir la guía APA del proyecto por haberla usado únicamente para dar formato;
- indicar cualquier dato que no haya podido verificarse.

## 12. Mensaje obligatorio cuando falte la guía del proyecto

Cuando `G01_Guia_Normas_APA_7_1.pdf` no esté disponible, incluir al final del resultado, fuera de la lista de Referencias:

> El formato APA 7 se aplicó con las reglas incluidas en la Skill; no se contrastó con G01_Guia_Normas_APA_7_1.pdf porque el archivo no estaba disponible en el proyecto.

No incluir este mensaje cuando:

- la guía estaba disponible;
- la guía fue consultada;
- el resultado se pudo revisar conforme a ella.

## 13. Uso de la guía como fuente citada

No citar `G01_Guia_Normas_APA_7_1.pdf` por haberla utilizado para aplicar formato.

Citarla únicamente si:

- se reproduce una definición contenida en la guía;
- se explica una regla de la guía;
- se discute su contenido;
- el usuario solicita justificar una decisión mediante esa guía;
- la actividad exige declarar los documentos normativos o metodológicos utilizados.

Cuando deba citarse, construir la referencia a partir de los datos reales del documento:

- autor o entidad responsable;
- año;
- título;
- versión o edición;
- institución;
- URL, si corresponde.

No inferir estos datos únicamente a partir del nombre del archivo.
