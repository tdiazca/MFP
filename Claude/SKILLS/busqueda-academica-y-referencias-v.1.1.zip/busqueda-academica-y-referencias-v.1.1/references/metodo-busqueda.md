# Método de búsqueda académica

## Índice

1. Formular la pregunta.
2. Construir las consultas.
3. Elegir las fuentes de búsqueda.
4. Cribar y eliminar duplicados.
5. Evaluar los candidatos.
6. Verificar el contenido y el nivel de acceso.
7. Documentar una investigación extensa.
8. Cerrar la búsqueda con transparencia.

## 1. Formular la pregunta

Antes de buscar, identificar los elementos relevantes de la consulta:

- concepto, tema o problema;
- población o etapa educativa;
- intervención, metodología o exposición;
- resultado o variable;
- contexto geográfico o institucional;
- periodo temporal;
- tipo de estudio o documento requerido.

No exigir que todos estos elementos aparezcan en todas las consultas.

Comenzar con una combinación suficientemente específica. Ampliar o restringir los términos según la cantidad, calidad y pertinencia de los resultados obtenidos.

Si la consulta del usuario es demasiado amplia, reformularla antes de comenzar. Si falta información imprescindible, formular únicamente las preguntas necesarias.

## 2. Construir las consultas

Preparar términos de búsqueda en español e inglés.

Incluir cuando corresponda:

- términos principales;
- sinónimos;
- variantes terminológicas y ortográficas;
- siglas y nombres desarrollados;
- términos equivalentes en inglés;
- descriptores o vocabularios controlados ofrecidos por la base;
- operadores booleanos;
- comillas para expresiones exactas;
- filtros compatibles con cada plataforma.

No limitarse a traducir literalmente una única consulta.

Crear varias combinaciones cuando el tema contenga conceptos que puedan expresarse de distintas formas.

### Ejemplo

Ejemplo de consulta:

    ("aprendizaje basado en proyectos" OR ABP OR "project-based learning")
    AND
    (secundaria OR "educación secundaria" OR "secondary education")
    AND
    (motivación OR motivation)

### Ajuste progresivo de las consultas

Si aparecen demasiados resultados:

- añadir la población o etapa educativa;
- añadir el contexto;
- incluir una variable concreta;
- limitar el periodo;
- buscar términos en el título;
- priorizar revisiones sistemáticas o estudios empíricos;
- excluir términos ambiguos cuando la plataforma lo permita.

Si aparecen pocos resultados:

- eliminar restricciones secundarias;
- ampliar el periodo;
- sustituir términos específicos por otros más amplios;
- utilizar sinónimos;
- buscar en inglés;
- probar otras bases o repositorios;
- eliminar filtros excesivamente restrictivos.

Registrar la consulta exacta en el modo de investigación extensa.

En la búsqueda rápida o académica, documentar las consultas solo cuando resulte útil para explicar o reproducir el resultado.

## 3. Elegir las fuentes de búsqueda

Seleccionar las fuentes según su adecuación al problema.

No utilizar siempre las mismas bases por rutina.

### Procedencia de los resultados

Registrar cómo se localizó cada candidato:

- búsqueda exploratoria;
- consulta por título o autor;
- fuente conocida previamente;
- fuente proporcionada por el usuario;
- cita localizada dentro de otra publicación;
- recomendación de un repositorio o página editorial.

Una consulta por título y autor sirve para verificar una publicación conocida, pero no constituye por sí sola un proceso de descubrimiento.

No describir como “resultado de la búsqueda” una fuente recuperada únicamente porque Claude ya conocía su título.

Cuando se utilicen fuentes conocidas previamente:

1. identificarlas como candidatas previas;
2. verificar sus datos;
3. ejecutar además alguna consulta exploratoria;
4. comparar su pertinencia con los resultados nuevos;
5. documentar su procedencia en la salida.

### Búsqueda multidisciplinar

Considerar:

- Google Scholar;
- catálogos académicos;
- bases multidisciplinares disponibles;
- páginas de editoriales y revistas científicas.

Utilizar Google Scholar principalmente para descubrir publicaciones.

Antes de verificar o citar una fuente encontrada en Google Scholar, abrir:

- el artículo original;
- la página de la revista;
- la página editorial;
- el repositorio institucional;
- el registro DOI;
- otro registro bibliográfico fiable.

No utilizar como enlace de verificación una página de resultados de Google Scholar.

### Educación

Priorizar, cuando sean pertinentes:

- ERIC;
- Dialnet;
- bases bibliográficas especializadas en educación;
- revistas científicas de educación;
- repositorios universitarios;
- repositorios institucionales.

### España e Iberoamérica

Considerar:

- Dialnet;
- SciELO;
- Redalyc;
- repositorios universitarios;
- portales institucionales;
- revistas científicas españolas e iberoamericanas.

### Acceso abierto

Considerar:

- DOAJ;
- SciELO;
- Redalyc;
- repositorios institucionales;
- repositorios temáticos fiables;
- versiones legales depositadas por los autores.

Distinguir entre:

- versión publicada;
- manuscrito aceptado;
- preprint;
- copia en repositorio.

No tratar automáticamente todas las versiones como equivalentes.

### Normativa educativa

Priorizar siempre la fuente oficial:

- Boletín Oficial del Estado;
- diarios oficiales autonómicos;
- ministerios;
- consejerías de educación;
- administraciones públicas;
- organismos responsables de emitir la norma.

No utilizar artículos divulgativos, blogs o resúmenes de terceros como sustitutos del texto oficial.

Pueden utilizarse para localizar o interpretar inicialmente una norma, pero la verificación final debe realizarse en la fuente oficial.

### Políticas e informes educativos

Considerar:

- Ministerio de Educación, Formación Profesional y Deportes;
- consejerías autonómicas;
- Instituto Nacional de Evaluación Educativa;
- UNESCO;
- OCDE;
- Comisión Europea;
- Eurydice;
- organismos públicos responsables del informe;
- universidades y centros de investigación reconocidos.

Verificar siempre:

- entidad responsable;
- fecha;
- edición;
- alcance territorial;
- metodología;
- versión disponible.

### Estadísticas

Utilizar preferentemente el organismo oficial responsable de producir el dato.

Comprobar:

- año o periodo;
- población analizada;
- unidad de medida;
- ámbito geográfico;
- metodología;
- revisiones o actualizaciones;
- diferencia entre dato provisional y definitivo.

No citar como fuente original una noticia o una página secundaria que reproduzca una estadística oficial.

### Publicaciones concretas

Cuando se conozca el título, autor, DOI o revista, buscar directamente en:

- la editorial;
- la revista;
- el repositorio institucional;
- el catálogo universitario;
- Crossref u otro registro DOI;
- la página oficial de la organización responsable.

## 4. Cribar y eliminar duplicados

Aplicar primero los criterios que puedan comprobarse rápidamente:

- coincidencia temática según el título y el resumen;
- población o etapa educativa;
- contexto;
- periodo;
- tipo de fuente admitido;
- existencia de datos bibliográficos verificables;
- acceso suficiente para el uso previsto;
- duplicados;
- versiones diferentes del mismo trabajo.

No analizar en profundidad una fuente que no supere esta primera revisión.

### Gestión de duplicados

Cuando haya varias versiones del mismo trabajo:

1. Identificar si se trata realmente de la misma publicación.
2. Conservar el registro bibliográfico más completo y estable.
3. Priorizar la versión publicada por la revista o editorial.
4. Utilizar una versión de repositorio cuando facilite el acceso legal al texto completo.
5. No contar distintas versiones como fuentes independientes.

Distinguir expresamente entre:

- preprint;
- manuscrito aceptado;
- versión publicada;
- capítulo;
- comunicación;
- tesis;
- informe derivado del mismo proyecto.

### Criterios iniciales de exclusión

Excluir o dejar en reserva fuentes que:

- solo mencionen superficialmente el tema;
- se refieran a una población o etapa no comparable;
- estén fuera del periodo sin ser fundacionales;
- carezcan de autoría o entidad responsable;
- no permitan verificar sus datos esenciales;
- sean páginas comerciales sin respaldo académico;
- sean trabajos de estudiantes utilizados como evidencia principal;
- sean resúmenes secundarios de una fuente original localizable;
- estén duplicadas;
- no ofrezcan acceso suficiente para sostener la afirmación prevista.

Registrar el motivo de exclusión cuando el modo de búsqueda lo requiera.

## 5. Evaluar los candidatos

Valorar cada candidato mediante una justificación breve y verificable.

No utilizar una puntuación numérica como sustituto del juicio académico, salvo que el usuario solicite una matriz de evaluación.

### Pertinencia

Comprobar:

- si responde directamente a la pregunta;
- si analiza el concepto principal;
- si aporta evidencia o solo menciona el tema;
- si cubre la variable o resultado solicitado;
- si resulta útil para la finalidad indicada.

### Aplicabilidad

Comprobar:

- población;
- etapa educativa;
- edad;
- contexto institucional;
- país o región;
- características sociales y educativas;
- similitud con el contexto del trabajo.

Cuando una fuente proceda de otro contexto, señalar los límites de transferibilidad.

No asumir que los resultados de Primaria, universidad o formación profesional son directamente aplicables a Secundaria.

### Actualidad

Priorizar el periodo solicitado.

Si el usuario no ha establecido un intervalo:

- priorizar los últimos cinco años;
- admitir publicaciones anteriores si son fundacionales;
- admitir estudios anteriores si continúan siendo relevantes;
- evitar excluir automáticamente investigaciones importantes solo por su antigüedad.

Explicar brevemente por qué se conserva una fuente anterior al intervalo principal.

### Tipo de fuente

Priorizar según la pregunta:

- revisiones sistemáticas;
- metaanálisis;
- estudios empíricos;
- artículos revisados por pares;
- libros y capítulos académicos;
- tesis doctorales;
- informes institucionales;
- normativa;
- estadísticas oficiales.

No considerar que un tipo de publicación es siempre superior a otro. Valorar si el tipo de fuente es adecuado para la afirmación que se pretende sostener.

### Calidad metodológica

Evaluar únicamente los aspectos que puedan comprobarse mediante el texto consultado.

Considerar, cuando corresponda:

- diseño;
- tamaño y selección de la muestra;
- instrumentos;
- procedimiento;
- análisis;
- control de sesgos;
- limitaciones reconocidas;
- adecuación entre método y conclusión.

No afirmar que un estudio tiene alta calidad metodológica si solo se ha consultado el título, la ficha bibliográfica o el resumen.

No deducir detalles metodológicos que no aparezcan en el contenido accesible.

### Autoridad

Comprobar:

- revisión por pares;
- revista o editorial;
- institución responsable;
- autoría identificable;
- estabilidad del documento;
- publicación oficial;
- existencia de DOI o registro bibliográfico;
- relación entre la entidad y el tema publicado.

El prestigio de una institución no sustituye la revisión del contenido y la metodología.

### Accesibilidad

Clasificar cada fuente como:

- texto completo;
- resumen;
- ficha bibliográfica.

Valorar si el nivel de acceso es suficiente para el uso previsto.

Una ficha bibliográfica puede servir para verificar la existencia de una publicación, pero no para atribuirle resultados o conclusiones.

### Complementariedad

Seleccionar un conjunto que, cuando sea posible:

- cubra diferentes enfoques;
- incluya fuentes recientes y fundacionales;
- combine revisiones y estudios empíricos;
- incorpore contextos relevantes;
- permita contrastar resultados;
- no repita innecesariamente la misma evidencia;
- muestre posibles desacuerdos.

### Indicadores bibliométricos

No utilizar de forma aislada:

- número de citas;
- factor de impacto;
- posición en Google Scholar;
- índice de la revista;
- popularidad del autor.

Estos indicadores pueden servir como información complementaria, pero no deben convertirse en el único criterio de calidad o pertinencia.

## 6. Verificar el contenido y el nivel de acceso

Para cada fuente seleccionada, intentar verificarla siguiendo este orden:

1. Documento original o texto completo.
2. Página oficial de la revista o editorial.
3. Repositorio institucional.
4. Registro DOI fiable.
5. Catálogo o índice bibliográfico secundario fiable.

No utilizar un índice secundario como única verificación cuando el documento original, la página editorial o el registro DOI estén accesibles.

Después:

1. Confirmar los datos bibliográficos.
2. Identificar el nivel real de acceso.
3. Registrar la procedencia del resultado.
4. Clasificar la referencia como verificada, provisional o insuficiente.
5. Extraer únicamente información respaldada por el contenido consultado.
6. Registrar las limitaciones relevantes.
7. Obtener un enlace estable de acceso o verificación.
8. Contrastar las afirmaciones importantes o discutidas con más de una fuente cuando sea posible.

Si no se consigue abrir una fuente primaria:

- indicarlo;
- identificar qué registro secundario se utilizó;
- no ocultar la limitación;
- no afirmar que la publicación fue consultada íntegramente.

### Datos bibliográficos que deben verificarse

Comprobar:

- autoría;
- orden de autores;
- año o fecha;
- título exacto;
- revista;
- editorial;
- institución;
- volumen;
- número;
- páginas;
- número de artículo;
- edición;
- DOI;
- URL;
- tipo de documento.

No completar por aproximación ningún dato ausente.

### Texto completo

Etiquetar como **Texto completo** únicamente cuando se haya accedido al documento completo.

Puede afirmarse información sobre:

- objetivo;
- marco;
- método;
- muestra;
- resultados;
- discusión;
- limitaciones;

siempre que esas partes hayan sido efectivamente consultadas.

### Resumen

Etiquetar como **Resumen** cuando solo se haya consultado el abstract o resumen.

En ese caso:

- limitar las afirmaciones a lo indicado expresamente;
- no describir detalles metodológicos ausentes;
- no ampliar las conclusiones;
- no presentar la fuente como leída íntegramente;
- señalar la limitación de acceso.

### Ficha bibliográfica

Etiquetar como **Ficha bibliográfica** cuando solo se haya comprobado el registro.

En ese caso:

- verificar la existencia de la fuente;
- proporcionar sus datos bibliográficos;
- no atribuir resultados;
- no resumir conclusiones;
- no inferir el contenido a partir del título.

### Limitaciones materiales

Registrar cuando sea relevante:

- tamaño reducido de la muestra;
- diseño no experimental;
- falta de grupo de comparación;
- instrumentos no descritos;
- contexto muy específico;
- antigüedad;
- barreras de acceso;
- texto parcial;
- dependencia del resumen;
- sesgos declarados;
- dificultad de transferir los resultados;
- resultados contradictorios.

### Contraste entre fuentes

Cuando varias fuentes coincidan:

- indicar la convergencia;
- evitar presentar coincidencia como prueba definitiva;
- considerar la independencia de las fuentes.

Cuando discrepen:

- describir la diferencia;
- comparar diseños, poblaciones, contextos y variables;
- señalar posibles explicaciones;
- no decidir artificialmente que una fuente es correcta sin evidencia suficiente.

## 7. Documentar una investigación extensa

En el modo de investigación extensa, registrar:

- fecha de búsqueda;
- base, buscador, portal o repositorio;
- consulta exacta;
- idioma;
- filtros;
- periodo;
- número de resultados revisados, cuando se conozca;
- criterios de inclusión;
- criterios de exclusión;
- duplicados;
- candidatos evaluados;
- fuentes incluidas;
- fuentes excluidas;
- motivo de exclusión;
- nivel de acceso;
- límites de cobertura.

### Registro de consultas

Conservar la consulta exacta utilizada en cada fuente de búsqueda.

No normalizar ni reescribir posteriormente una consulta de forma que deje de reflejar lo que realmente se buscó.

### Criterios de inclusión

Definir, según la investigación:

- tema;
- población;
- etapa educativa;
- contexto;
- periodo;
- idiomas;
- tipo de estudio;
- tipo de publicación;
- nivel de acceso mínimo;
- variables;
- calidad o verificabilidad.

### Criterios de exclusión

Definir, según corresponda:

- población no pertinente;
- etapa educativa distinta;
- publicación fuera del intervalo;
- idioma no admitido;
- duplicado;
- fuente sin datos verificables;
- falta de acceso suficiente;
- publicación no académica;
- estudio sin relación directa;
- versión sustituida por otra más completa.

### Matriz de evidencia

Organizar las fuentes seleccionadas mediante campos como:

- identificador;
- referencia APA 7;
- diseño;
- fuente;
- población;
- contexto;
- variables;
- hallazgos;
- limitaciones;
- nivel de acceso;
- enlace de verificación.

No completar columnas con información no consultada.

Utilizar expresiones como:

- no consta en el contenido consultado;
- no verificable con el nivel de acceso disponible;
- solo consta en el resumen.

### Denominación del trabajo

Utilizar términos como **revisión sistemática** o **revisión exhaustiva** únicamente cuando el procedimiento cumpla realmente esos estándares.

En caso contrario, denominarlo:

- búsqueda estructurada;
- revisión narrativa;
- exploración documentada;
- revisión bibliográfica no sistemática;
- búsqueda académica amplia.

No presentar una búsqueda realizada únicamente mediante Google Scholar como una revisión sistemática.

## 8. Cerrar la búsqueda con transparencia

Al finalizar, indicar:

- fuentes de búsqueda consultadas;
- periodos cubiertos;
- idiomas;
- filtros principales;
- número de fuentes seleccionadas;
- nivel de acceso;
- barreras encontradas;
- datos que no pudieron verificarse;
- afirmaciones basadas únicamente en resúmenes;
- limitaciones de cobertura;
- aspectos que podrían ampliarse en una ronda posterior.

No afirmar:

> No existe literatura sobre este tema.

Cuando solo pueda afirmarse:

> No se encontraron resultados válidos en las fuentes y consultas realizadas.

No afirmar que la búsqueda fue exhaustiva si:

- no se consultaron suficientes bases;
- existieron barreras de acceso;
- se limitó el número de resultados;
- se aplicaron filtros restrictivos;
- no se revisó toda la literatura relevante;
- no se siguió un protocolo de revisión sistemática.

Cerrar con una formulación proporcionada al alcance real de la búsqueda.
