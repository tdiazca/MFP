# Plantillas de salida

## Instrucciones generales

Seleccionar la plantilla correspondiente al modo de búsqueda.

Adaptar los campos y las columnas a la consulta concreta.

No incluir columnas vacías que no aporten información.

No repetir la misma información en:

- aporte principal;
- hallazgo;
- utilidad;
- pertinencia;
- síntesis;
- limitaciones.

Mantener siempre separados:

- la referencia en APA 7;
- el enlace adicional de acceso o verificación;
- el nivel real de acceso.

Aplicar la jerarquía de APA 7 definida en `SKILL.md` y `references/apa7.md`.

No convertir automáticamente el enlace de verificación en parte de la referencia.

## 1. Plantilla de búsqueda rápida

Utilizar esta plantilla cuando el usuario necesite un número reducido de fuentes y una respuesta breve.

### Configuración de la búsqueda

- **Tema o pregunta:** [tema o pregunta de investigación]
- **Finalidad:** [actividad, foro, contraste, definición u otra]
- **Número de fuentes solicitado:** [cantidad o intervalo]
- **Periodo:** [intervalo temporal]
- **Idiomas:** [idiomas utilizados]
- **Población o etapa educativa:** [dato]
- **Contexto geográfico o institucional:** [dato]
- **Tipos de fuente priorizados:** [tipos]
- **Fuentes de búsqueda consultadas:** [buscadores, bases, portales o repositorios]

Si alguno de estos datos no fue indicado por el usuario, identificar el valor predeterminado aplicado.

### Fuentes seleccionadas

| N.º | Referencia APA 7 | Estado de la referencia | Procedencia | Tipo de fuente | Aporte principal | Utilidad y cautelas | Nivel de acceso | Enlace de verificación |
|---:|---|---|---|---|---|---|---|---|
| 1 | [referencia] | [verificada, provisional o insuficiente] | [descubierta, conocida previamente, proporcionada o citada indirectamente] | [tipo] | [síntesis] | [utilidad y cautela] | [texto completo, resumen o ficha bibliográfica] | [enlace estable] |

### Síntesis breve

Redactar un párrafo corto que:

- compare los aportes principales;
- indique qué fuente resulta más útil para cada aspecto;
- señale coincidencias o diferencias relevantes;
- evite elaborar un marco teórico completo.

### Cobertura real de la búsqueda

- **Herramientas y fuentes realmente consultadas:** [lista]
- **Fuentes mencionadas pero no accesibles directamente:** [lista]
- **Consultas exploratorias realizadas:** [lista o resumen]
- **Consultas por título o autor:** [lista o resumen]
- **Fuentes conocidas previamente utilizadas como candidatas:** [lista]
- **Páginas editoriales o documentos originales abiertos:** [lista]
- **Repositorios o índices secundarios utilizados:** [lista]

No mencionar como consultada una plataforma que no se haya abierto o utilizado realmente.

### Limitaciones

Indicar brevemente:

- cobertura de la búsqueda;
- barreras de acceso;
- fuentes consultadas únicamente mediante resumen;
- ausencia de resultados que cumplan todos los criterios;
- límites de aplicabilidad al contexto solicitado.

### Comprobación APA 7 de la búsqueda rápida

Si `G01_Guia_Normas_APA_7_1.pdf` no estaba disponible, añadir al final:

> El formato APA 7 se aplicó con las reglas incluidas en la Skill; no se contrastó con G01_Guia_Normas_APA_7_1.pdf porque el archivo no estaba disponible en el proyecto.

No incluir esta nota cuando la guía estaba disponible y fue consultada.

## 2. Plantilla de búsqueda académica: fase 1

Utilizar esta plantilla para presentar fuentes candidatas antes de realizar la selección definitiva.

No redactar todavía el trabajo académico.

### Estrategia aplicada

- **Tema o pregunta:** [tema o pregunta]
- **Finalidad:** [uso previsto]
- **Fuentes candidatas previstas:** [número]
- **Fuentes finales previstas:** [número]
- **Periodo:** [intervalo]
- **Idiomas:** [idiomas]
- **Población o etapa educativa:** [dato]
- **Contexto geográfico o institucional:** [dato]
- **Tipos de fuente admitidos:** [tipos]
- **Fuentes de búsqueda consultadas:** [lista]
- **Consultas utilizadas:** [resumen de las consultas]
- **Criterios de inclusión:** [criterios]
- **Criterios de exclusión:** [criterios]

En búsquedas académicas normales, resumir las consultas utilizadas.

No es necesario registrar todas las variaciones menores, salvo que ayuden a explicar o reproducir la búsqueda.

### Fuentes candidatas verificadas

| ID | Referencia APA 7 | Estado de la referencia | Procedencia | Tipo y contexto | Pertinencia | Limitaciones | Nivel de acceso | Enlace de verificación | Decisión preliminar |
|---|---|---|---|---|---|---|---|---|---|
| C1 | [referencia] | [verificada, provisional o insuficiente] | [descubierta, conocida previamente, proporcionada o citada indirectamente] | [tipo y contexto] | [pertinencia] | [limitación] | [nivel] | [enlace] | [seleccionar, reserva o excluir] |

La descripción completa de cada fuente candidata no debe superar tres frases, salvo petición expresa.

### Criterios utilizados para la decisión preliminar

Valorar conjuntamente:

- relación directa con la pregunta;
- adecuación de la población y la etapa educativa;
- aplicabilidad al contexto;
- actualidad o carácter fundacional;
- tipo de fuente;
- calidad metodológica que pueda comprobarse;
- autoridad académica o institucional;
- nivel de acceso;
- complementariedad con otras fuentes;
- datos bibliográficos verificables.

### Cierre de la fase 1

Si el usuario desea seleccionar las fuentes, preguntar:

> ¿Qué fuentes candidatas quieres conservar para la selección final?

Si el usuario ha delegado la selección, indicar:

> Aplicaré los criterios definidos y seleccionaré las fuentes más pertinentes, verificables y complementarias.

No iniciar una redacción extensa en esta fase.

## 3. Plantilla de búsqueda académica: fase 2

Utilizar esta plantilla después de que el usuario haya seleccionado las fuentes o haya delegado la selección definitiva.

### Fuentes seleccionadas en la fase final

| ID | Referencia APA 7 verificada | Motivo de selección | Hallazgo utilizable | Limitación o cautela | Nivel de acceso | Enlace de verificación |
|---|---|---|---|---|---|---|
| C1 | [referencia definitiva] | [criterios de selección] | [síntesis limitada al contenido consultado] | [limitación relevante] | [texto completo, resumen o ficha bibliográfica] | [enlace estable] |

### Justificación de la selección

Explicar brevemente:

- por qué se eligieron estas fuentes;
- qué aspectos cubre cada fuente;
- qué fuentes se complementan;
- qué fuentes presentan resultados distintos;
- qué candidatos fueron descartados y por qué, cuando resulte relevante.

### Síntesis comparativa

Redactar uno o dos párrafos breves sobre:

- principales coincidencias;
- diferencias entre resultados o enfoques;
- utilidad de las fuentes para la pregunta;
- límites de aplicabilidad;
- aspectos que no quedan suficientemente cubiertos.

No elaborar un marco teórico completo.

No atribuir resultados o conclusiones que no estén respaldados por el nivel de acceso indicado.

### Posible uso posterior

Indicar, cuando resulte útil:

- qué fuente puede respaldar una definición;
- qué fuente puede respaldar una afirmación sobre resultados;
- qué fuente aporta una revisión general;
- qué fuente resulta aplicable al contexto educativo solicitado;
- qué fuente debería utilizarse con cautela.

### Referencias

Si el usuario solicita una bibliografía limpia, presentar una sección titulada **Referencias**.

Incluir exclusivamente las referencias seleccionadas y verificadas.

No añadir en esta sección:

- comentarios;
- anotaciones;
- enlaces adicionales de verificación;
- niveles de acceso;
- fuentes descartadas.

### Comprobación APA 7 de la selección final

Si `G01_Guia_Normas_APA_7_1.pdf` no estaba disponible, añadir fuera de la lista de Referencias:

> El formato APA 7 se aplicó con las reglas incluidas en la Skill; no se contrastó con G01_Guia_Normas_APA_7_1.pdf porque el archivo no estaba disponible en el proyecto.

## 4. Plantilla de investigación extensa

Utilizar esta plantilla para TFM, estados de la cuestión, revisiones bibliográficas amplias o búsquedas que requieran trazabilidad.

### Alcance

- **Pregunta de investigación:** [pregunta]
- **Finalidad:** [finalidad]
- **Periodo cubierto:** [intervalo]
- **Fecha de la búsqueda:** [fecha]
- **Idiomas:** [idiomas]
- **Población o etapa educativa:** [dato]
- **Contexto geográfico o institucional:** [dato]
- **Tipos de fuente admitidos:** [tipos]
- **Nivel mínimo de acceso:** [texto completo, resumen u otro]
- **Criterio de cierre:** [máximo de fuentes o criterio de cobertura]

### Método

- **Fuentes de búsqueda:** [bases, buscadores, repositorios y portales]
- **Criterios de inclusión:** [lista]
- **Criterios de exclusión:** [lista]
- **Procedimiento de cribado:** [descripción]
- **Procedimiento de verificación:** [descripción]
- **Gestión de duplicados:** [descripción]
- **Limitaciones previstas:** [descripción]

### Registro de búsquedas

| Fecha | Base, buscador o repositorio | Consulta exacta | Filtros aplicados | Resultados revisados | Observaciones |
|---|---|---|---|---:|---|
| [fecha] | [fuente] | [consulta exacta] | [periodo, idioma, tipo u otros] | [número, si se conoce] | [incidencias o ajustes] |

No inventar el número de resultados revisados.

Si la plataforma no permite conocerlo, escribir:

> No consta con precisión.

### Flujo de selección

Registrar cuando sea posible:

- resultados identificados;
- duplicados detectados;
- fuentes cribadas;
- fuentes excluidas inicialmente;
- candidatos evaluados;
- textos completos consultados;
- fuentes finales seleccionadas.

No utilizar terminología propia de una revisión sistemática formal si el proceso no cumple esos requisitos.

### Matriz de evidencia

| ID | Referencia APA 7 | Diseño o tipo de fuente | Población y contexto | Variables o foco | Hallazgos | Limitaciones | Nivel de acceso | Enlace de verificación |
|---|---|---|---|---|---|---|---|---|
| E1 | [referencia] | [diseño o tipo] | [muestra y contexto] | [variables o tema] | [síntesis verificable] | [limitaciones] | [texto completo, resumen o ficha] | [enlace] |

No completar una columna con información no consultada.

Utilizar, cuando corresponda:

- No consta en el contenido consultado.
- No verificable con el nivel de acceso disponible.
- Solo consta en el resumen.
- No se informa en la fuente consultada.

### Fuentes excluidas relevantes

| Fuente o ID | Fase de exclusión | Motivo de exclusión |
|---|---|---|
| [fuente] | [cribado, verificación o selección] | [duplicado, contexto no pertinente, datos no verificables, acceso insuficiente u otro] |

No es necesario documentar individualmente todas las exclusiones cuando el volumen sea muy alto.

Registrar al menos:

- exclusiones dudosas;
- fuentes aparentemente relevantes;
- fuentes descartadas por falta de acceso;
- publicaciones excluidas por datos no verificables;
- versiones duplicadas importantes.

### Síntesis de resultados

Organizar la síntesis por:

- temas;
- variables;
- tipos de intervención;
- resultados;
- contextos;
- diseños;
- coincidencias;
- contradicciones;
- lagunas.

No redactar el TFM ni un capítulo completo.

La síntesis debe servir como base documental para una redacción posterior.

### Lagunas detectadas

Identificar:

- poblaciones poco estudiadas;
- ausencia de investigaciones en el contexto solicitado;
- resultados contradictorios;
- escasez de estudios recientes;
- falta de estudios empíricos;
- ausencia de acceso al texto completo;
- variables no suficientemente analizadas.

### Cobertura real de la búsqueda en la investigación extensa

- **Herramientas y fuentes realmente consultadas:** [lista]
- **Fuentes mencionadas pero no accesibles directamente:** [lista]
- **Consultas exploratorias realizadas:** [lista o resumen]
- **Consultas por título o autor:** [lista o resumen]
- **Fuentes conocidas previamente utilizadas como candidatas:** [lista]
- **Páginas editoriales o documentos originales abiertos:** [lista]
- **Repositorios o índices secundarios utilizados:** [lista]

No mencionar como consultada una plataforma que no se haya abierto o utilizado realmente.

### Limitaciones de la búsqueda

Declarar:

- fuentes o bases no disponibles;
- barreras de acceso;
- sesgos de idioma;
- límites temporales;
- límites geográficos;
- restricciones sobre tipos de publicación;
- filtros utilizados;
- alcance real de la búsqueda;
- aspectos que convendría ampliar.

No presentar la búsqueda como exhaustiva cuando no pueda demostrarse.

## 5. Plantilla de ficha bibliográfica detallada

Utilizar esta ficha cuando el usuario necesite analizar cada fuente por separado.

### [ID]. [Título de la fuente]

- **Referencia APA 7:** [referencia verificada]
- **Tipo de fuente:** [artículo, revisión, metaanálisis, informe, tesis, norma u otro]
- **Autoría o entidad:** [dato]
- **Año:** [dato]
- **Publicación o institución:** [dato]
- **Contexto geográfico:** [dato]
- **Población o etapa educativa:** [dato]
- **Pregunta u objetivo:** [dato]
- **Método o diseño:** [solo si se consultó]
- **Muestra:** [solo si se consultó]
- **Variables o foco:** [dato verificable]
- **Hallazgo relevante:** [información respaldada]
- **Utilidad para la consulta:** [explicación breve]
- **Limitaciones:** [cautelas]
- **Nivel de acceso:** [texto completo, resumen o ficha bibliográfica]
- **DOI:** [DOI verificado, si existe]
- **Enlace de acceso o verificación:** [enlace estable]

No completar un campo mediante suposiciones.

Si el dato no consta, utilizar una de estas formulaciones:

- No consta en el contenido consultado.
- No verificable con el nivel de acceso disponible.
- Solo consta parcialmente en el resumen.
- No aplicable a este tipo de fuente.

## 6. Plantilla de bibliografía comentada

Utilizar cuando el usuario solicite referencias acompañadas de una explicación breve.

### [Referencia APA 7]

**Síntesis:**  
[Resumen breve del contenido consultado.]

**Utilidad:**  
[Explicar para qué aspecto de la consulta resulta útil.]

**Limitaciones:**  
[Indicar límites metodológicos, contextuales o de acceso.]

**Nivel de acceso:**  
[Texto completo, resumen o ficha bibliográfica.]

**Enlace de verificación:**  
[Enlace estable.]

Mantener la anotación separada de la referencia.

No presentar una bibliografía comentada como una lista limpia de Referencias.

## 7. Plantilla de lista limpia de Referencias

En el documento académico final, titular la sección **Referencias**.

Incluir las referencias APA 7 en orden alfabético.

Reglas:

- No numerar, salvo instrucción expresa.
- No añadir comentarios.
- No añadir etiquetas de nivel de acceso.
- No añadir motivos de selección.
- No añadir enlaces independientes de comprobación.
- Mantener únicamente DOI o URL cuando formen parte de la referencia conforme a APA 7.
- Aplicar sangría francesa cuando el formato lo permita.
- Comprobar que cada referencia está citada en el texto.
- Comprobar que cada cita tiene su referencia.
- No incluir fuentes consultadas pero no utilizadas.

## 8. Plantilla de comparación de fuentes

Utilizar cuando el usuario necesite contrastar evidencia.

| Criterio | Fuente 1 | Fuente 2 | Fuente 3 |
|---|---|---|---|
| Referencia abreviada | [autor, año] | [autor, año] | [autor, año] |
| Tipo de fuente | [tipo] | [tipo] | [tipo] |
| Población y contexto | [dato] | [dato] | [dato] |
| Método o enfoque | [dato verificable] | [dato verificable] | [dato verificable] |
| Hallazgo principal | [síntesis] | [síntesis] | [síntesis] |
| Limitaciones | [cautelas] | [cautelas] | [cautelas] |
| Aplicabilidad | [valoración] | [valoración] | [valoración] |
| Nivel de acceso | [nivel] | [nivel] | [nivel] |

Después de la tabla, añadir una síntesis breve que:

- identifique coincidencias;
- describa discrepancias;
- explique diferencias de contexto o diseño;
- evite declarar una fuente superior sin justificación.

## 9. Plantilla de respuesta cuando no se encuentren fuentes suficientes

Utilizar una formulación transparente:

> No se encontraron suficientes fuentes que cumplieran todos los criterios establecidos en las consultas y fuentes de búsqueda revisadas.

Indicar:

- número de fuentes válidas encontradas;
- criterios que no pudieron cumplirse;
- barreras de acceso;
- consultas utilizadas;
- fuentes de búsqueda revisadas;
- posibles alternativas para ampliar la búsqueda.

No afirmar:

> No existe literatura sobre el tema.

Proponer, cuando proceda:

- ampliar el periodo;
- incluir otros idiomas;
- ampliar el contexto geográfico;
- utilizar términos más generales;
- considerar otros tipos de publicaciones;
- consultar bases adicionales;
- aceptar temporalmente fuentes disponibles solo mediante resumen.

No modificar los criterios sin informar al usuario.

## 10. Plantilla de transparencia sobre el nivel de acceso

Utilizar estas etiquetas de forma coherente:

### Texto completo

> Se consultó el documento completo. La síntesis puede incluir información del objetivo, método, resultados, discusión y limitaciones efectivamente revisadas.

### Resumen

> Solo se consultó el resumen. La síntesis se limita a la información expresamente incluida en él y no permite valorar todos los detalles metodológicos.

### Ficha bibliográfica

> Solo se verificó el registro bibliográfico. La fuente puede incluirse como candidata, pero no se le atribuyen resultados ni conclusiones.

## 11. Mensaje cuando falte la guía APA del proyecto

Cuando `G01_Guia_Normas_APA_7_1.pdf` no esté disponible, añadir al final, fuera de la lista de Referencias:

> El formato APA 7 se aplicó con las reglas incluidas en la Skill; no se contrastó con G01_Guia_Normas_APA_7_1.pdf porque el archivo no estaba disponible en el proyecto.

No añadir este mensaje cuando:

- la guía estaba disponible;
- fue consultada;
- el resultado pudo revisarse conforme a ella.

## 12. Comprobación final de la salida

Antes de entregar, verificar:

- que se utilizó la plantilla correspondiente al modo;
- que se respetó el número de fuentes solicitado;
- que las fuentes existen;
- que los datos bibliográficos fueron comprobados;
- que el nivel de acceso está correctamente etiquetado;
- que las síntesis no exceden la información consultada;
- que las referencias siguen la jerarquía APA 7;
- que se consultó `G01_Guia_Normas_APA_7_1.pdf` cuando estaba disponible;
- que la guía no se incorporó indebidamente a las Referencias;
- que los enlaces de verificación están separados;
- que no se duplicó información;
- que las limitaciones están visibles;
- que no se exageró el alcance de la búsqueda;
- que no se redactó un trabajo completo;
- que no se inventó ningún dato.
