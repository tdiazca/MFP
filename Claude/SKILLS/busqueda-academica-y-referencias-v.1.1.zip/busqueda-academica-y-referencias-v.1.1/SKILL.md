---
name: busqueda-academica-y-referencias
description: Localizar, seleccionar, verificar y organizar fuentes académicas, institucionales, oficiales y normativas para actividades universitarias. Usar cuando se necesite una búsqueda rápida, una búsqueda académica en dos fases o una investigación extensa; preparar fichas, bibliografías comentadas o matrices de evidencia; comprobar referencias y citas en APA 7; o entregar enlaces verificables sin inventar datos. Contextualizar brevemente los resultados, pero no redactar trabajos, foros ni capítulos extensos.
---

# Búsqueda académica y referencias

## Objetivo y límites

Localizar, seleccionar, verificar y presentar fuentes útiles y trazables.

Contextualizar los resultados mediante síntesis breves, sin sustituir la redacción académica posterior.

No redactar automáticamente:

- actividades completas;
- participaciones finales en foros;
- capítulos extensos de un marco teórico;
- trabajos académicos completos;
- un Trabajo Fin de Máster.

No reemplazar el análisis personal del usuario.

Si el usuario solicita también una redacción extensa, entregar primero la base documental y explicar que la redacción queda fuera del alcance principal de esta Skill, salvo que otra Skill o instrucción específica cubra esa tarea.

## Flujo general

1. Identificar el tema o pregunta, la finalidad, el modo de búsqueda y el número o alcance de fuentes.
2. Formular únicamente las preguntas imprescindibles que todavía no estén respondidas.
3. Definir consultas, fuentes de búsqueda y criterios de selección.
4. Cribar los resultados antes de analizarlos en profundidad.
5. Verificar la identidad bibliográfica, el acceso y el contenido realmente consultado.
6. Seleccionar las fuentes finales según criterios explícitos.
7. Formatear las citas y referencias conforme a la jerarquía APA 7 definida en esta Skill.
8. Presentar los resultados, sus limitaciones y los enlaces de verificación.
9. Ejecutar la comprobación final antes de afirmar que la búsqueda está completa.

Consultar:

- `references/metodo-busqueda.md` para construir consultas, seleccionar buscadores y bases, cribar y evaluar fuentes.
- `references/apa7.md` para citas, referencias, DOI, URL y correspondencia bibliográfica.
- `references/plantillas-salida.md` para los formatos de salida de cada modo.

## Configuración adaptativa

Extraer primero del mensaje toda la información ya disponible.

No repetir preguntas que el usuario ya haya respondido.

Agrupar en un solo mensaje las preguntas imprescindibles.

Antes de iniciar la búsqueda, comprobar que se conocen estas cuatro variables:

- **Tema o pregunta de investigación.**
- **Finalidad:** actividad breve, trabajo evaluable, foro, marco teórico, TFM, contraste de una afirmación, comprensión general u otra.
- **Modo:** búsqueda rápida, búsqueda académica o investigación extensa.
- **Número o alcance de fuentes:** cifra exacta, intervalo, máximo o criterio de cobertura.

La finalidad es obligatoria porque puede modificar la selección de fuentes.

Si el usuario no indica la finalidad y esta no puede inferirse claramente de su solicitud, preguntarla antes de buscar.

No sustituir la finalidad por expresiones como “sin finalidad concreta” o “búsqueda general” salvo que el usuario confirme que solo desea una exploración general.

### Comportamiento por defecto

- Si falta el tema, preguntar antes de buscar.
- Si falta la finalidad y no puede inferirse claramente, preguntar antes de buscar.
- Si el usuario confirma que desea una exploración general, registrar la finalidad como **comprensión general**.
- Si falta el modo, recomendarlo según la finalidad y comunicar la elección.
- Si falta únicamente el número de fuentes, aplicar el valor predeterminado del modo y comunicarlo brevemente.
- Si ampliar el número cambia sustancialmente el alcance, preguntar antes de comenzar.
- Tratar el periodo, contexto, idioma, tipos de estudio y formato como parámetros opcionales, salvo que sean decisivos para responder correctamente.

### Valores predeterminados

- **Periodo:** últimos cinco años, admitiendo fuentes anteriores cuando sean fundacionales o especialmente relevantes.
- **Idiomas:** español e inglés.
- **Fuentes:** artículos revisados por pares y fuentes académicas, institucionales u oficiales.
- **Contexto:** el indicado en la actividad. Si no aparece, utilizar contextos educativos comparables y señalar los límites de transferibilidad.
- **Formato:** tabla breve con referencia APA 7, síntesis, utilidad, limitaciones, nivel de acceso y enlace de verificación.

## Declaración previa de la búsqueda

Antes de ejecutar la búsqueda, informar brevemente al usuario de:

- modo seleccionado;
- finalidad;
- número de fuentes que se entregarán;
- número máximo de candidatos que se revisarán, cuando corresponda;
- periodo temporal;
- idiomas;
- tipos de fuente priorizados;
- fuentes de búsqueda que se prevé consultar;
- limitaciones conocidas de acceso.

No afirmar que se buscará directamente en Google Scholar, ERIC, Dialnet, SciELO, Redalyc, Scopus, Web of Science u otra plataforma si no existe acceso real a ella.

Si solo puede utilizarse un buscador web general, indicarlo antes de comenzar.

Antes de limitar la búsqueda a la herramienta web general, comprobar si está disponible el navegador integrado o cualquier herramienta que permita acceder directamente a Google Scholar, ERIC, Dialnet, SciELO, Redalyc, DOAJ, repositorios universitarios u otras fuentes académicas pertinentes.

Si el navegador integrado está disponible:

- utilizarlo cuando mejore la cobertura o permita consultar directamente una fuente académica;
- priorizarlo para abrir páginas editoriales, artículos, repositorios, registros DOI y fuentes institucionales;
- utilizarlo para acceder directamente a Google Scholar u otras bases cuando la plataforma lo permita;
- registrar qué plataformas se consultaron realmente;
- no confundir la apertura de una página mediante el navegador con una búsqueda completa dentro de su base de datos.

No pedir autorización adicional para utilizar el navegador integrado cuando el usuario ya haya solicitado una búsqueda académica o en Internet.

Si el navegador integrado no está disponible o no puede acceder a una plataforma:

- continuar con la búsqueda web general;
- utilizar consultas restringidas por dominio cuando resulte útil;
- declarar la limitación antes de presentar los resultados;
- no afirmar que se realizó una búsqueda directa en esa plataforma.

Solo cuando el navegador integrado o el acceso directo no estén disponibles, utilizar consultas restringidas por dominio para localizar resultados en portales académicos. Explicar que este método no equivale a una búsqueda directa dentro de sus interfaces.

### Ejemplo de declaración previa

> Aplicaré una búsqueda rápida para una actividad breve y seleccionaré tres fuentes finales, publicadas preferentemente durante los últimos cinco años. Buscaré en español e inglés mediante búsqueda web académicamente orientada. No presentaré como consultada ninguna base a la que no haya accedido realmente.
>
> Intentaré verificar cada fuente mediante el documento original, la página editorial, un repositorio institucional o un registro DOI fiable. Si solo puedo acceder a un registro secundario, lo indicaré expresamente y la referencia permanecerá como provisional cuando falten datos.

Adaptar el ejemplo al modo, la finalidad, el número de fuentes, el periodo, los idiomas y las posibilidades reales de acceso de cada búsqueda.

No afirmar que todas las fuentes serán verificadas antes de comprobar que las fuentes primarias o los registros fiables son accesibles.

## Selección del modo

### 1. Búsqueda rápida

Usar para:

- comprender o definir un concepto;
- preparar una actividad breve;
- obtener evidencias para un foro;
- contrastar inicialmente una afirmación;
- localizar un número reducido de fuentes.

Reglas:

- Entregar el número solicitado de fuentes finales.
- Si el usuario no indica un número, seleccionar tres fuentes.
- Cribar suficientes resultados para no aceptar simplemente los primeros encontrados.
- Intentar utilizar al menos dos vías complementarias:
  - una vía de descubrimiento académico;
  - una fuente primaria, página editorial, registro DOI, repositorio institucional o fuente oficial para verificar cada publicación seleccionada.
- No es obligatorio consultar todas las bases académicas disponibles en una búsqueda rápida.
- Si solo está disponible la búsqueda web general, declararlo antes de buscar y reflejarlo después en las limitaciones.
- No presentar la búsqueda como realizada en Google Scholar, ERIC, Dialnet, SciELO, Redalyc u otra base si únicamente se utilizaron consultas web que apuntaban a esos dominios.
- No afirmar que las fuentes seleccionadas son “las mejores disponibles” si no se ha realizado una búsqueda comparativa suficiente.
- Utilizar formulaciones como **“fuentes pertinentes y verificadas dentro del alcance de esta búsqueda”** cuando la cobertura sea limitada.
- Presentar una síntesis mínima y descriptiva de cada fuente.
- Mantener la respuesta breve y centrada en utilidad, limitaciones y trazabilidad.

#### Trazabilidad en búsqueda rápida

Mantener la trazabilidad breve y útil.

Por defecto, indicar únicamente:

- herramientas utilizadas;
- plataformas académicas consultadas directamente;
- consultas principales;
- procedencia de las fuentes seleccionadas;
- nivel de acceso;
- fuentes primarias, páginas editoriales, repositorios o registros DOI utilizados para la verificación;
- limitaciones relevantes de cobertura o acceso.

No incluir por defecto detalles técnicos de navegación que no afecten a la calidad o reproducibilidad académica, como:

- autorizaciones de acceso concedidas por el navegador;
- número de veces que se autorizó un dominio;
- pasos de navegación internos;
- redirecciones técnicas irrelevantes;
- información operativa sobre la interfaz.

Incluir trazabilidad técnica detallada únicamente cuando:

- el usuario solicite auditar la búsqueda;
- se esté probando el funcionamiento de la Skill;
- sea necesario explicar una limitación;
- se utilice el modo de investigación extensa.

En una búsqueda rápida, priorizar una salida compacta que permita saber qué se buscó, dónde se buscó, qué se encontró y hasta qué nivel se verificó.

No enumerar todas las fuentes descartadas en una búsqueda rápida salvo que su exclusión sea relevante para interpretar los resultados.

### 2. Búsqueda académica

Usar para:

- actividades evaluables;
- marcos teóricos breves;
- búsquedas que requieran comparar candidatos;
- selección razonada de evidencias.

Trabajar en dos fases:

#### Fase 1. Candidatos

- Localizar, cribar y verificar una lista preliminar.
- Presentar una ficha breve de cada candidato.
- No redactar todavía el trabajo.
- Permitir que el usuario seleccione las fuentes o delegue la selección.

#### Fase 2. Selección final

- Seleccionar las mejores fuentes según los criterios acordados.
- Verificar de nuevo los datos bibliográficos.
- Entregar las referencias, síntesis y cautelas definitivas.

Valores predeterminados:

- Seis fuentes candidatas.
- Cuatro fuentes seleccionadas.

Si el usuario solo indica el número final, revisar inicialmente como máximo el doble de fuentes, salvo que sea necesario ampliar la búsqueda para encontrar suficientes resultados válidos.

Limitar la descripción preliminar de cada candidata a un máximo de tres frases.

Distinguir siempre entre:

- fuentes localizadas;
- fuentes candidatas;
- fuentes seleccionadas.

### 3. Investigación extensa

Usar para:

- TFM;
- estados de la cuestión;
- revisiones bibliográficas amplias;
- investigaciones que requieran documentación del procedimiento.

Reglas:

- Acordar un límite máximo de fuentes o un criterio de cobertura.
- No imponer un número rígido por defecto.
- Documentar consultas, buscadores, bases, repositorios, fecha de búsqueda y filtros.
- Definir criterios de inclusión y exclusión.
- Registrar duplicados y exclusiones relevantes cuando sea necesario para la trazabilidad.
- Organizar una matriz de evidencia o bibliografía comentada.
- Declarar el alcance real de la búsqueda.
- No denominar sistemática o exhaustiva una revisión que no cumpla esos métodos.
- Entregar una base documental organizada, no redactar el TFM.

## Estrategia de búsqueda

Construir términos en español e inglés a partir de la pregunta.

No limitarse a traducir literalmente una única consulta.

Combinar, cuando proceda:

- concepto o problema;
- sinónimos;
- población;
- etapa educativa;
- contexto;
- intervención o metodología;
- resultado o variable;
- periodo;
- tipo de estudio.

Buscar en las fuentes más adecuadas para cada pregunta.

Considerar, entre otras:

- Google Scholar;
- ERIC;
- Dialnet;
- SciELO;
- Redalyc;
- DOAJ;
- repositorios universitarios;
- catálogos académicos;
- páginas de editoriales y revistas científicas;
- organismos oficiales;
- ministerios;
- BOE y otros diarios oficiales;
- bases especializadas disponibles.

No utilizar siempre las mismas fuentes por rutina.

Para normativa, estadísticas o políticas públicas, priorizar la fuente oficial.

Para afirmaciones científicas, priorizar la publicación original o su registro editorial verificable.

Google Scholar debe utilizarse principalmente para descubrir fuentes. Antes de verificar o citar un resultado, abrir el documento original, su página editorial, el repositorio institucional o un registro bibliográfico fiable.

### Procedencia de las fuentes candidatas

Distinguir entre:

- **Fuente descubierta durante la búsqueda:** apareció como resultado de las consultas ejecutadas.
- **Fuente conocida previamente:** Claude ya conocía su existencia antes de ejecutar la búsqueda.
- **Fuente proporcionada por el usuario:** fue facilitada mediante un archivo, referencia, DOI o enlace.
- **Fuente citada indirectamente:** apareció citada dentro de otra publicación, pero todavía no se ha consultado directamente.

Las fuentes conocidas previamente pueden utilizarse como candidatas, pero:

- deben identificarse expresamente como fuentes conocidas previamente;
- deben verificarse externamente;
- no deben sustituir la búsqueda exploratoria;
- no deben presentarse como descubiertas mediante las consultas;
- deben compararse con los resultados obtenidos durante la búsqueda;
- no deben seleccionarse automáticamente por familiaridad o notoriedad.

Las fuentes citadas indirectamente no deben presentarse como consultadas hasta que se haya abierto y verificado su documento o registro original.

## Uso de los materiales del proyecto

Cuando existan materiales en el proyecto:

- Extraer conceptos, autores y términos útiles sin resumir de nuevo todos los documentos.
- Buscar fuentes que amplíen, respalden, contradigan o actualicen esos materiales.
- Diferenciar entre materiales del proyecto, fuentes externas y análisis elaborado.
- No presentar como consultada una fuente que únicamente aparezca citada indirectamente en otro documento.

## Criterios de selección

Valorar conjuntamente:

- relación directa con la pregunta;
- adecuación de la población, etapa y contexto;
- actualidad o carácter fundacional;
- tipo de publicación;
- revisión por pares;
- calidad metodológica que pueda comprobarse;
- autoridad y estabilidad de la entidad publicadora;
- acceso suficiente para sostener las afirmaciones;
- complementariedad entre fuentes;
- diversidad de perspectivas;
- posibles contradicciones.

Priorizar, cuando sean pertinentes:

- revisiones sistemáticas;
- metaanálisis;
- estudios empíricos;
- artículos revisados por pares;
- fuentes institucionales;
- documentos oficiales;
- normativa publicada por el organismo competente.

No utilizar como evidencia principal:

- blogs;
- páginas comerciales;
- resúmenes divulgativos;
- páginas sin autoría identificable;
- trabajos de estudiantes;
- contenidos sin datos verificables.

Solo utilizar estos tipos de contenidos si la pregunta trata específicamente sobre ellos y se identifican claramente como tales.

## Verificación y niveles de acceso

### Estado de verificación de la referencia

Clasificar cada referencia como una de las siguientes:

- **Referencia APA 7 verificada:** se han comprobado todos los datos bibliográficos necesarios para el tipo de fuente.
- **Referencia APA 7 provisional:** la fuente existe, pero falta comprobar uno o más datos necesarios.
- **Datos insuficientes para construir la referencia:** no puede elaborarse una referencia fiable con la información disponible.

No presentar una referencia como verificada cuando falten datos obligatorios, como:

- autoría;
- fecha;
- título;
- publicación;
- volumen o número, cuando correspondan;
- páginas o identificador;
- DOI o URL exigible.

Una referencia provisional puede incluirse en una lista de candidatos, pero no debe incorporarse a una bibliografía académica final hasta completar su verificación.

Indicar expresamente qué dato falta en una referencia provisional.

Antes de incluir una fuente, comprobar mediante la fuente primaria, la página editorial, el registro DOI, el repositorio institucional o un catálogo bibliográfico fiable:

- autoría o entidad responsable;
- año o fecha;
- título exacto;
- revista, editorial, institución o norma;
- volumen y número;
- páginas o identificador;
- DOI o URL que corresponda;
- tipo de fuente;
- existencia real;
- coincidencia entre los registros consultados.

Etiquetar el nivel real de acceso:

- **Texto completo:** se consultó el documento completo.
- **Resumen:** solo se consultó el abstract o resumen.
- **Ficha bibliográfica:** solo se verificó el registro.

No presentar una fuente como leída si no se consultó el texto completo.

No atribuir métodos, resultados o conclusiones basándose únicamente en el título.

Si solo se accedió al resumen:

- indicarlo expresamente;
- limitar las afirmaciones a lo que el resumen respalda;
- no inferir información metodológica no disponible.

Excluir referencias cuya existencia o cuyos datos esenciales no puedan verificarse.

### Verificación bibliográfica e idoneidad académica

Distinguir siempre entre dos decisiones independientes:

- **Verificación bibliográfica:** determina si los datos necesarios de la fuente han sido comprobados y permiten construir una referencia APA 7 fiable.
- **Idoneidad académica:** determina si la fuente es suficientemente pertinente, rigurosa y adecuada para la finalidad concreta del usuario.

Una referencia bibliográficamente verificada puede no ser adecuada para el trabajo si su población, contexto, metodología, objeto de estudio o nivel de evidencia no son suficientemente pertinentes.

Una fuente académicamente pertinente no debe incorporarse a una bibliografía académica final mientras su referencia siga siendo provisional o contenga datos bibliográficos esenciales sin verificar.

No afirmar que una referencia verificada necesita comprobación bibliográfica adicional salvo que exista un dato concreto pendiente. Si existe, indicar exactamente qué dato falta y clasificar la referencia como provisional.

Al presentar una fuente, diferenciar cuando sea necesario:

- **Estado bibliográfico:** verificada, provisional o datos insuficientes.
- **Idoneidad para la finalidad:** alta, moderada, limitada o no recomendada, acompañada de una justificación breve.

No confundir una limitación del estudio con un problema de verificación bibliográfica.

## Referencia normativa APA 7

Aplicar esta jerarquía al elaborar o revisar citas y referencias:

1. Instrucciones expresas de la actividad, rúbrica o universidad.
2. `G01_Guia_Normas_APA_7_1.pdf`, cuando esté disponible en el proyecto.
3. `references/apa7.md` para casos no cubiertos o cuando la guía no esté disponible.

Si el proyecto contiene el archivo exacto `G01_Guia_Normas_APA_7_1.pdf`:

- localizarlo;
- utilizarlo como referencia principal para el formato APA 7;
- consultar únicamente los apartados pertinentes al tipo de fuente;
- utilizarlo también durante la revisión final.

No añadir `G01_Guia_Normas_APA_7_1.pdf` a la bibliografía por el mero hecho de utilizarlo para dar formato.

Solo incluir la guía en las referencias cuando:

- se cite su contenido;
- se explique una regla contenida en la guía;
- el usuario solicite justificar una decisión de formato utilizando la guía.

Si la guía no está disponible:

- aplicar las reglas incluidas en `references/apa7.md`;
- indicar al final:

> El formato APA 7 se aplicó con las reglas incluidas en la Skill; no se contrastó con G01_Guia_Normas_APA_7_1.pdf porque el archivo no estaba disponible en el proyecto.

Si la guía está disponible pero no cubre un caso:

- aplicar la regla complementaria de `references/apa7.md`;
- indicar únicamente cuando resulte relevante que el caso no estaba cubierto por la guía.

Si existe una contradicción material entre la guía, la rúbrica y las reglas complementarias, explicar la contradicción y solicitar confirmación antes de aplicar una alternativa.

## Referencias APA y enlaces de verificación

Separar siempre:

### Referencia APA 7

- Incluir DOI o URL únicamente cuando corresponda según APA 7 y la guía principal.
- No añadir enlaces que APA 7 no requiera.
- Presentar el DOI como `https://doi.org/...`.
- Si existe DOI, utilizarlo en la referencia en lugar de una URL ordinaria, salvo que la guía principal indique otra cosa.

### Enlace de acceso o verificación

- Proporcionarlo por separado en la ficha de búsqueda.
- Utilizarlo para que el usuario pueda acceder a la fuente o comprobar su existencia.
- No convertirlo automáticamente en parte de la referencia APA.

No incluir en la lista de Referencias:

- enlaces de resultados de Google Scholar;
- enlaces de sesión;
- enlaces de redirección;
- enlaces de seguimiento;
- URLs adicionales que no correspondan según APA 7.

No inventar ni completar por aproximación:

- autores;
- fechas;
- títulos;
- revistas;
- editoriales;
- volúmenes;
- números;
- páginas;
- DOI;
- URL.

Cuando el usuario solicite un texto con citas, mantener correspondencia completa:

- cada cita debe tener su referencia;
- cada referencia incluida debe estar citada;
- no deben aparecer fuentes no utilizadas en la lista final.

## Salida

Adaptar el formato al modo y a la petición.

Como mínimo, incluir para cada fuente seleccionada:

- referencia en APA 7;
- tipo de fuente;
- síntesis breve limitada al contenido consultado;
- utilidad para la pregunta;
- limitaciones o cautelas;
- nivel de acceso;
- enlace independiente de acceso o verificación.

Cuando se solicite una bibliografía limpia, entregar una sección titulada **Referencias** que contenga únicamente las referencias APA 7.

No mezclar en esa sección:

- comentarios;
- anotaciones;
- enlaces adicionales de comprobación;
- fuentes descartadas.

Distinguir:

- hechos confirmados;
- interpretación;
- información no verificable;
- resultados basados únicamente en resúmenes.

Señalar los desacuerdos entre fuentes en lugar de forzar un consenso.

No afirmar que una búsqueda es exhaustiva si no puede demostrarse.

## Control de alcance y consumo

- Respetar el máximo de fuentes solicitado.
- Cribar antes de analizar en profundidad.
- No analizar exhaustivamente los candidatos que no superen la revisión inicial de pertinencia.
- No repetir la misma información en el resumen, la utilidad y el hallazgo.
- No procesar todos los materiales del proyecto si no son necesarios.
- No realizar rondas ilimitadas.
- No ampliar sustancialmente el alcance sin confirmación.
- No producir un marco teórico ni una síntesis extensa salvo petición expresa y cobertura autorizada por otra instrucción o Skill.

## Comprobación final

Antes de entregar:

- Confirmar que cada fuente existe.
- Confirmar que los datos bibliográficos esenciales coinciden.
- Confirmar que cada afirmación se apoya en el nivel de acceso declarado.
- Confirmar que las fuentes cumplen los criterios acordados.
- Confirmar que se respeta el número solicitado.
- Confirmar que las referencias y citas siguen la jerarquía APA 7.
- Confirmar que se consultó `G01_Guia_Normas_APA_7_1.pdf` cuando estaba disponible.
- Confirmar que la guía del proyecto no se añadió indebidamente a la bibliografía.
- Confirmar que los enlaces de verificación están separados de las referencias APA.
- Confirmar que las limitaciones, exclusiones y conflictos relevantes son visibles.
- Confirmar que no se inventaron datos.
- Confirmar que no se exageró el alcance de la búsqueda.
- Confirmar que cada referencia está identificada como verificada, provisional o insuficiente.
- Confirmar que ninguna referencia provisional aparece como definitiva en una bibliografía académica.