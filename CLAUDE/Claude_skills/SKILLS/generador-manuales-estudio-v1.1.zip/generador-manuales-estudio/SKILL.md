---
name: generador-manuales-estudio
description: crear, ampliar o revisar manuales de estudio por tema para un máster a partir de un pdf de unidad, una presentación, transcripciones de clase y notas o aclaraciones del docente. usar cuando el usuario pida transformar esos materiales en un manual completo, visual, esquemático y orientado al examen, sin consultar internet ni añadir información externa.
---

# Generador de manuales de estudio

## Objetivo

Crear un manual de estudio de un único tema que sea completo, manejable y fácil de repasar. Basar el contenido en el PDF de la unidad y enriquecerlo solo con información útil de la presentación, las transcripciones y las aclaraciones del docente.

## 1. Validar los materiales

Antes de redactar:

1. Identificar y clasificar los archivos disponibles:
   - PDF de la unidad.
   - Presentación de clase.
   - Transcripción o transcripciones.
   - Aclaraciones o correcciones del docente.
   - Otros materiales del tema.
2. Comprobar que pertenecen al mismo tema.
3. Si falta el PDF, la presentación o la transcripción, o un archivo es ilegible o parece pertenecer a otro tema, informar al usuario y pedir confirmación antes de continuar.

## 2. Aplicar la jerarquía de fuentes

Usar exclusivamente los materiales proporcionados. No consultar internet ni añadir conocimientos externos, aunque sean correctos.

Aplicar esta jerarquía funcional:

1. **PDF de la unidad**: fuente principal para la estructura, los conceptos y el nivel de profundidad.
2. **Presentación**: apoyo para detectar síntesis, relaciones, clasificaciones y contenidos destacados.
3. **Transcripciones**: apoyo para añadir explicaciones, ejemplos, comparaciones, advertencias y énfasis del docente.
4. **Aclaraciones posteriores del docente**: prioridad cuando corrijan, precisen o sustituyan información anterior.

Si las fuentes discrepan:

- Aplicar la aclaración más reciente del docente cuando exista.
- Señalar las contradicciones relevantes que no puedan resolverse.
- No completar lagunas mediante suposiciones.

## 3. Integrar y sintetizar

Crear un único manual, no resúmenes separados por archivo.

- Incluir todos los conceptos relevantes del PDF sin copiarlo párrafo por párrafo.
- Incorporar de las fuentes complementarias solo matices que mejoren la comprensión, el estudio o la preparación del examen.
- Eliminar saludos, repeticiones orales, digresiones y comentarios sin valor académico.
- Evitar repetir la misma información en el desarrollo, las tablas y los resúmenes.
- Mantener una extensión similar o moderadamente superior a la del PDF base, sin contar la autoevaluación y las soluciones.
- Reducir extensión mediante organización y síntesis, nunca eliminando conceptos importantes.
- Priorizar el formato con mayor rendimiento didáctico: tablas para comparar o clasificar, esquemas para procesos y relaciones, listas para enumeraciones y texto breve para explicar conceptos. No convertir automáticamente la información en tablas si el texto facilita más la comprensión.

## 4. Tratar la orientación al examen

Distinguir claramente:

- **Confirmado por el docente**: indicado expresamente como importante, imprescindible o evaluable.
- **Enfatizado por el docente**: repetido, explicado o ejemplificado, sin confirmación expresa de examen.
- **Central en el tema**: fundamental según el PDF.

No presentar inferencias como contenidos confirmados del examen.

## 5. Redactar el manual

Usar lenguaje académico, claro y directo. Mantener la terminología de los materiales. Explicar lo suficiente para comprender, sin relleno ni párrafos innecesariamente largos.

Seguir esta estructura:

### 1. Identificación

Incluir asignatura, número y título del tema, materiales utilizados y materiales ausentes o descartados.

### 2. De qué trata el tema

Resumir en 3 a 5 líneas el objeto del tema y la relación entre sus bloques.

### 3. Mapa general

Mostrar los apartados y sus relaciones mediante un esquema jerárquico comentado.

### 4. Desarrollo por apartados

Seguir la estructura del PDF. Para cada apartado, incluir solo cuando corresponda:

- idea principal;
- conceptos y definiciones;
- explicación;
- fases, características o clasificaciones;
- ejemplos o aclaraciones del docente;
- relación con otros conceptos.

### 5. Lo que destaca el docente

Separar:

- contenidos confirmados como importantes;
- posibles contenidos de examen basados en pistas;
- ideas enfatizadas;
- aclaraciones, advertencias y errores frecuentes.

### 6. Conceptos que pueden confundirse

Usar una tabla comparativa con significado, diferencia principal, ejemplo y regla para recordarlos. Incluir solo comparaciones respaldadas por los materiales.

### 7. Autores, fases, modelos y clasificaciones

Crear tablas separadas cuando resulte útil. No mezclar categorías diferentes en una única tabla.

### 8. Correcciones y puntos poco claros

Recoger solo correcciones, contradicciones, ambigüedades o errores de transcripción que puedan afectar a la comprensión, al estudio o a la respuesta en el examen. Omitir erratas formales, bibliográficas o de transcripción sin consecuencias sobre el contenido que debe aprenderse.

### 9. Resumen en 10 ideas

Sintetizar el tema en diez ideas concretas y completas.

### 10. Repaso ultrarrápido

Incluir conceptos imprescindibles, enumeraciones, relaciones, reglas mnemotécnicas, diferencias clave y orientación al examen con su grado de certeza.

Se pueden crear reglas mnemotécnicas nuevas cuando faciliten el estudio, pero deben identificarse expresamente como **mnemotecnia generada por Claude** y no atribuirse al docente ni a los materiales. Las mnemotecnias no pueden modificar, simplificar de forma inexacta ni añadir contenido académico.

### 11. Autoevaluación

Crear:

- 20 preguntas tipo test con 4 opciones y una sola respuesta correcta.
- 5 preguntas de desarrollo corto.

Cubrir todos los apartados relevantes y dar mayor presencia a los contenidos destacados. Colocar las soluciones al final.

Para cada test, incluir respuesta correcta y justificación breve. Para cada pregunta de desarrollo, incluir respuesta modelo breve y conceptos imprescindibles.

## 6. Formato de salida

Entregar en PDF por defecto o en Word si el usuario lo solicita.

Diseñar un documento visual y funcional con:

- títulos jerarquizados;
- párrafos breves;
- listas;
- tablas comparativas;
- esquemas;
- palabras clave en negrita;
- recuadros para aclaraciones y contenidos importantes.

Elegir cada recurso según su utilidad didáctica: tablas para comparar o clasificar; esquemas para procesos, jerarquías y relaciones; listas para enumeraciones que deban memorizarse; y texto breve para explicar conceptos. No convertir automáticamente la información en tablas si el texto resulta más claro. Evitar decoración sin función didáctica.

## 7. Verificación final

Antes de entregar, comprobar que:

- aparecen todos los conceptos importantes del PDF;
- la estructura principal respeta el PDF;
- las fuentes complementarias aportan valor sin duplicar contenido;
- se aplican las aclaraciones posteriores;
- no se incorpora información externa;
- no se inventan autores, ejemplos ni referencias;
- se señalan las contradicciones relevantes;
- el manual es completo, pero no innecesariamente largo;
- las preguntas pueden responderse con el manual;
- las soluciones coinciden con el contenido.

Si no puede cumplirse algún requisito, indicarlo antes de generar el documento.
