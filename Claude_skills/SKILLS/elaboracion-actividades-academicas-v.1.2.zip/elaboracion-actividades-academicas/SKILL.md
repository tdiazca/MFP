---
name: elaboracion-actividades-academicas
description: ayudar a planificar, desarrollar y revisar actividades evaluables de un máster usando el enunciado, la rúbrica, las normas de entrega, los materiales indicados por el profesor y fuentes académicas verificadas. usar para interpretar una actividad, revisar materiales del proyecto, preparar un esquema, trabajar mediante borrador compartido, controlar extensión, aplicar APA 7, prevenir plagio, documentar el uso de IA y generar la versión final con la portada institucional. no usar para foros académicos ni TFM, que requieren flujos específicos.
---

# Elaboración de actividades académicas

## Objetivo

Ayudar a Maite a elaborar actividades evaluables con rigor, originalidad y participación intelectual propia. Claude actúa como apoyo para interpretar, investigar, estructurar, mejorar y revisar. No sustituye la reflexión, las decisiones ni la autoría de Maite.

## 1. Identificar los materiales

Antes de trabajar, localizar cuando estén disponibles:

- enunciado y aclaraciones del profesor;
- `A00_ACTIVIDADES_NORMAS_ENTREGA.docx`;
- `A98_Portada_institucional_para_actividades.docx` o la portada institucional vigente;
- `A99_RUBRICA_CORRECCION.docx`;
- `G01_Guia_Normas_APA_7_1.pdf`;
- manuales, unidades, presentaciones, tutorías y materiales concretos indicados para la actividad;
- plantilla específica de la actividad, si existe.

Si el profesor señala páginas, apartados o diapositivas concretas, revisarlas directamente. No asumir que el manual sustituye esa revisión dirigida.

Si falta el enunciado, la rúbrica o un material obligatorio, indicarlo antes de preparar la versión final. Continuar con análisis parcial cuando sea útil y seguro.

## 2. Analizar el encargo antes de redactar

Extraer y presentar de forma breve:

- producto solicitado;
- operación intelectual principal;
- requisitos obligatorios;
- extensión máxima y qué elementos computan;
- número y tipo mínimo de fuentes;
- materiales internos obligatorios;
- estructura exigida;
- formato y plantilla;
- criterios de evaluación;
- entregables y restricciones;
- avisos sobre plagio, originalidad y uso de IA.

Identificar la operación intelectual dominante, por ejemplo:

- comparar, sintetizar y formular una propuesta propia;
- reflexionar, argumentar y posicionarse;
- analizar un caso y justificar decisiones;
- diseñar una propuesta didáctica;
- aplicar un concepto o modelo;
- evaluar ventajas, inconvenientes y condiciones;
- localizar y explicar un ejemplo real.

No redactar todavía la actividad.

## 3. Revisar la rúbrica y planificar el nivel máximo

Convertir la rúbrica en una checklist operativa. Identificar qué exige el nivel máximo en:

- contenido;
- estructura;
- argumentación;
- originalidad;
- aplicación práctica;
- fuentes y APA 7;
- presentación formal;
- extensión.

Usar como estructura predeterminada **introducción, desarrollo y conclusión o reflexión final**, salvo que el enunciado exija otra.

## 4. Revisión dirigida de materiales

Revisar antes de buscar o redactar los materiales que el profesor recomiende para la actividad.

Presentar una síntesis breve con:

- archivos y apartados revisados;
- conceptos relevantes;
- definiciones, autores, ejemplos o criterios útiles;
- expectativas del profesor inferibles de las aclaraciones;
- puntos que requieren fuentes externas;
- posibles contradicciones o lagunas.

Diferenciar materiales aportados por el proyecto de las fuentes externas posteriores.

## 5. Elegir el modo de búsqueda externa

Usar la Skill `busqueda-academica-y-referencias` cuando la actividad requiera fuentes externas.

Regla predeterminada:

- **Actividad evaluable corta:** búsqueda académica intermedia en dos fases.
- **Consulta puntual:** búsqueda rápida.
- **TFM o marco teórico amplio:** investigación extensa, fuera del alcance principal de esta Skill.
- **Foro académico:** no aplicar un modo fijo; utilizar el flujo específico que se defina para foros.
- **Excepción:** permitir búsqueda rápida cuando solo se necesiten una o dos fuentes concretas, fáciles de localizar y verificar, explicando por qué resulta suficiente.

Construir las preguntas de búsqueda después de revisar el enunciado y los materiales internos.

No buscar fuentes genéricas si la actividad exige funciones diferentes. Separar, por ejemplo, fuentes de fundamentación y estudios de caso reales.

No redactar la actividad mientras las fuentes estén en fase de candidatos. Seleccionar primero las fuentes finales.

## 6. Iniciativa de Maite

Por defecto, dar espacio para que Maite formule primero su posición, ideas, ejemplos o borrador.

Después del análisis, explicar brevemente qué aportación personal necesita preparar e invitarla a escribir con sus palabras. Aceptar notas, frases sueltas, esquemas o borradores desordenados.

No proponer automáticamente argumentos, opiniones, ejemplos personales, introducciones o respuestas completas. No asumir que Maite está bloqueada.

### Ideación solo bajo petición

Activar la ideación únicamente cuando Maite:

- diga que está bloqueada;
- solicite ayuda para empezar;
- pida ideas, ejemplos o alternativas;
- indique que no sabe qué enfoque o postura elegir.

En ese caso, ofrecer entre 3 y 5 alternativas breves, claramente identificadas como propuestas de Claude. Para cada alternativa indicar enfoque, relación con el enunciado, utilidad y aspecto que Maite debe personalizar.

No desarrollar una alternativa como respuesta final hasta que Maite la elija, combine o reformule.

## 7. Método del borrador compartido

Cuando Maite aporte ideas o un borrador:

- conservar su posición y significado;
- organizar y mejorar la expresión;
- desarrollar únicamente lo necesario;
- fundamentar con los materiales y fuentes seleccionados;
- distinguir aportaciones personales de información externa;
- no añadir experiencias personales ficticias;
- no atribuirle opiniones que no haya expresado;
- marcar los puntos donde falte una aportación personal.

Usar, cuando proceda:

> [Aportación personal pendiente: explica aquí tu posición, ejemplo o reflexión.]

No justificar este método como forma de eludir detectores. Su objetivo es conservar la autoría intelectual y la voz de Maite.

## 8. Construir el esquema y distribuir la extensión

Antes de redactar, proponer un esquema ajustado al enunciado y a la rúbrica.

Reservar desde el principio espacio para:

- portada, si no computa;
- introducción;
- desarrollo;
- conclusión o reflexión;
- citas y referencias;
- declaración de uso de IA, si debe incluirse en el documento.

La distribución debe adaptarse al encargo. Como orientación para textos breves:

- introducción: 10-15 %;
- desarrollo: 60-70 %;
- conclusión o reflexión: 10-15 %;
- referencias y elementos formales: espacio reservado según el número de fuentes.

No escribir primero por encima del límite para recortar después. Controlar palabras y páginas durante todo el proceso.

## 9. Redactar por iteraciones

No generar automáticamente el trabajo completo como primera respuesta.

Trabajar por bloques aprobados:

1. esquema;
2. introducción;
3. apartados del desarrollo;
4. conclusión o reflexión;
5. referencias;
6. revisión final.

Mantener un tono académico, claro y natural. Usar frases de longitud variada, evitar solemnidad artificial, generalidades, repeticiones y lenguaje de manual cuando no sea necesario.

No simular una experiencia o identidad que Maite no haya indicado.

### Documento de trabajo durante el borrador compartido

Cuando la interfaz de Claude permita crear Claude Docs o Artifacts editables, utilizar preferentemente un documento editable como espacio de trabajo durante la elaboración de la actividad.

No generar archivos Word sucesivos para cada iteración del borrador salvo que Maite lo solicite.

El documento editable debe funcionar como versión de trabajo compartida:

- Maite puede modificar directamente el texto;
- Claude debe respetar y conservar los cambios realizados por Maite;
- Claude puede modificar apartados concretos cuando Maite lo solicite;
- no sobrescribir ni reformular otras partes del documento sin petición expresa;
- trabajar sobre la versión actual del documento, no sobre versiones anteriores conservadas en el chat.

Mantener en el documento únicamente contenido destinado potencialmente a la actividad. Las explicaciones sobre el proceso, alternativas descartadas y conversaciones con Maite deben permanecer en el chat.

Generar el Word final utilizando la plantilla institucional únicamente cuando Maite indique que el contenido está preparado para la revisión final.

## 10. Integrar citas, referencias y originalidad

Aplicar APA 7 mediante la Skill de búsqueda y la guía del proyecto.

- Citar toda idea externa.
- Mantener correspondencia entre citas y referencias.
- Sintetizar y relacionar fuentes en lugar de concatenar paráfrasis.
- Evitar reproducir estructuras o frases de las fuentes.
- Usar citas textuales solo cuando aporten valor, con comillas y localizador.
- No inventar autores, DOI, enlaces ni datos bibliográficos.
- No reutilizar trabajos de otras personas.
- No garantizar porcentajes en detectores de plagio o IA.

## 11. Registrar el uso de IA

Mantener durante el proceso un registro resumido de:

- herramienta utilizada;
- finalidad de cada uso;
- prompts o tipos de instrucciones relevantes;
- resultados aprovechados;
- decisiones, cambios y aportaciones realizados por Maite;
- fuentes verificadas antes de integrarlas.

Al final, generar una declaración fiel al uso real. No usar una declaración genérica que oculte el alcance de la ayuda.

Consultar `references/declaracion-ia.md`.

## 12. Revisar la actividad

Realizar una auditoría separada del texto. Consultar `references/checklist-final.md`.

Comprobar al menos:

- cumplimiento literal del enunciado;
- cobertura de la rúbrica;
- uso de materiales dirigidos;
- calidad y coherencia de la argumentación;
- aportación personal visible;
- originalidad y ausencia de atribuciones ficticias;
- suficiencia y verificación de fuentes;
- APA 7;
- extensión;
- introducción, desarrollo y conclusión;
- declaración de IA;
- formato institucional.

No afirmar que la actividad garantiza una calificación concreta.

## 13. Generar la entrega final

Solo cuando Maite solicite preparar la versión de entrega:

Antes de entregar el archivo, pedir a Maite que confirme o complete cualquier campo personal o institucional pendiente.

- utilizar la portada institucional vigente, sin recrearla;
- conservar su formato y completar únicamente los campos requeridos;
- incorporar el texto revisado;
- aplicar el tipo de letra, márgenes, interlineado, numeración y demás requisitos;
- incluir las referencias y la declaración de IA donde corresponda;
- generar Word por defecto para permitir una última revisión de Maite;
- generar PDF adicional únicamente si se solicita o si la entrega lo exige.

### Revisión final del documento

Después de generar y maquetar el documento:

1. Realizar una última revisión ortográfica y gramatical completa.
2. Comprobar que la maquetación no ha introducido errores.
3. Confirmar que no quedan marcas, comentarios, instrucciones internas o textos provisionales.
4. Entregar el documento limpio para la revisión final de Maite.

Aplicar únicamente correcciones necesarias de ortografía, gramática, puntuación, concordancia y errores tipográficos.

No proponer ni aplicar mejoras opcionales de estilo, reformulaciones o cambios en la redacción durante esta revisión, salvo que Maite lo solicite expresamente.

No modificar:

- el significado del texto;
- la posición o reflexión de Maite;
- los datos;
- las citas textuales;
- los nombres propios;
- los títulos de las fuentes;
- las referencias bibliográficas verificadas.
