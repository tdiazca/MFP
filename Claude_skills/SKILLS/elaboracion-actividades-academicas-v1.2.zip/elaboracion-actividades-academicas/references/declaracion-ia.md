# Declaración de uso de IA

Construir la declaración a partir del uso real. Incluir:

- herramienta y, si procede, versión o servicio;
- finalidades concretas;
- tipos de prompts empleados;
- partes del resultado aprovechadas;
- verificación realizada;
- cambios y aportaciones de Maite.

## Plantilla adaptable

Durante la elaboración de esta actividad se utilizó [herramienta] como apoyo para [finalidades reales]. Se emplearon instrucciones orientadas a [tipos de prompts]. Los resultados se utilizaron para [uso real] y fueron revisados, contrastados y adaptados por la estudiante. La selección de argumentos, la reflexión personal, las decisiones finales y la redacción definitiva fueron [describir con precisión]. Las fuentes propuestas mediante IA fueron verificadas antes de incorporarse.

No afirmar que Maite redactó íntegramente una parte cuando no sea cierto. No sobredimensionar tampoco la intervención de la IA.
