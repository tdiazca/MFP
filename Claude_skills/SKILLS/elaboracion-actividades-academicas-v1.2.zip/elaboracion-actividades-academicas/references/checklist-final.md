# Checklist final

## Encargo

- Se responde a todos los verbos y apartados del enunciado.
- Se cumplen mínimos, máximos y entregables.
- Se utilizaron los materiales indicados por el profesor.

## Estructura

- Introducción o encabezado adecuado.
- Desarrollo proporcionado.
- Conclusión o reflexión propia.
- Transiciones y coherencia interna.

## Autoría y contenido

- La posición de Maite es visible.
- No hay experiencias u opiniones inventadas.
- Los ejemplos están contextualizados y no son genéricos sin necesidad.
- Se distingue reflexión propia de evidencia externa.

## Fuentes y APA

- Fuentes suficientes y pertinentes.
- Datos bibliográficos verificados.
- Cada afirmación externa tiene cita.
- Cada cita tiene referencia y viceversa.
- DOI y URL se usan según APA 7 y la guía del proyecto.

## Originalidad

- No hay bloques copiados.
- Las paráfrasis son genuinas.
- Las citas textuales están marcadas y localizadas.
- No se reutilizan trabajos ajenos ni propios sin indicarlo.

## Extensión y formato

- Se respeta el límite incluyendo los elementos que computan.
- Se usa la portada institucional.
- Se conservan tipografía y formato exigidos.
- Los campos institucionales están completos.

## Uso de IA

- La declaración refleja el uso real.
- Se documentan finalidad, prompts y forma de integración.
- Se indica la revisión y aportación personal de Maite.
