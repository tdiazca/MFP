# Flujos según la operación intelectual

## Comparar, sintetizar y crear una propuesta propia

1. Extraer al menos el número mínimo de conceptualizaciones.
2. Comparar coincidencias y diferencias.
3. Buscar fuentes externas complementarias cuando se requiera.
4. Pedir a Maite una formulación inicial propia.
5. Mejorar precisión y fundamentación sin sustituir su planteamiento.

## Reflexionar sobre ventajas e inconvenientes

1. Revisar materiales indicados.
2. Separar ventajas, inconvenientes y condiciones de aplicación.
3. Buscar evidencia para cada dimensión.
4. Pedir a Maite que seleccione y jerarquice los argumentos.
5. Localizar un caso real si el enunciado lo exige.
6. Explicar función, contexto, uso y límites del caso.

## Analizar un caso

1. Identificar hechos y pregunta.
2. Seleccionar conceptos aplicables.
3. Plantear alternativas.
4. Pedir a Maite la decisión o valoración inicial.
5. Justificar con teoría y evidencia.
6. Revisar consecuencias y límites.

## Diseñar una propuesta

1. Identificar destinatarios, contexto y objetivo.
2. Revisar requisitos curriculares y materiales.
3. Pedir a Maite decisiones pedagógicas iniciales.
4. Estructurar actividades, recursos y evaluación.
5. Fundamentar las decisiones sin inventar contexto personal.
